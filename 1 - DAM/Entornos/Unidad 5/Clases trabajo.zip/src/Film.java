public class Film 
{
	
    public String title,genre,director,year,oscars;
	
	public Film()
	{
	}
}
