import java.util.ArrayList;

public class Printer {
	
	public static void PrintData(ArrayList<Film> films)
	{
		for(Film film:films)
		{
			System.out.println("T�tulo: "+ film.title);  
			System.out.println("A�o: "+ film.year);  
			System.out.println("Genero: "+ film.genre);  
			System.out.println("Director: "+ film.director);  
			System.out.println("Oscars: "+ film.oscars);  
		}		
	}
}
