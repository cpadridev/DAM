import java.util.ArrayList;

import org.w3c.dom.Document;

public class Main {
	
	public void main(String[] args){
		
		Document doc = DocBuilder.GetDocFromXmlFile();
		ArrayList<Film> films = DataBuilder.GetFilmListFromDoc(doc);
		Printer.PrintData(films);
	}

}
