import java.util.ArrayList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DataBuilder {
	
	private static ArrayList<Film> films;
	
	public static ArrayList<Film> GetFilmListFromDoc(Document doc)
	{
		films = new ArrayList<Film>();
		
		NodeList nodeList = doc.getElementsByTagName("pelicula");
		
		for (int temp = 0; temp < nodeList.getLength(); temp++) {

            Node node = nodeList.item(temp);

            if (node.getNodeType() == Node.ELEMENT_NODE) {

                Element element = (Element) node;
                
                Film film = new Film();
                film.title = element.getElementsByTagName("title").item(0).getTextContent();
                film.director = element.getElementsByTagName("director").item(0).getTextContent();
                film.genre = element.getElementsByTagName("genre").item(0).getTextContent();
                film.oscars = element.getElementsByTagName("oscars").item(0).getTextContent();
                film.year = element.getElementsByTagName("year").item(0).getTextContent();
                
                films.add(film);
            }
        }
		
		return films;
		
	}

}
