package _02ejemplos._01tiempo;

public class Test2 {
	public static void main(String[] args) {
		Tiempo t = new Tiempo();
		System.out.println(t.toString());
	}

}
