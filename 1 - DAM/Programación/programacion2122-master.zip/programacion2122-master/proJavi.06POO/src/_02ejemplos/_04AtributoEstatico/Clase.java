package _02ejemplos._04AtributoEstatico;

public class Clase {
	int x; //Atributo de instancia
	int y; //Atributo de instancia
	static int z; //Atributo DE CLASE

}
