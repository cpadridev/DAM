package _02ejemplos._04AtributoEstatico;

public class Constantes {
	//Un uso habitual de atributos estáticos son las constantes.
	//Se hace para ahorrar memoria
	
	final static int METROSPORKM = 1000;
	

}
