package examen;

public class Ejercicio5 {
	// ---- TEST -------------------------------------------------------
	public static void main(String[] args) {
		int[] perfilCarrera = { 90, 110, 110, 220, 210, 140, 140, 110, 150, 200, 170, 180, 130, 150, 110, 170, 150, 160,
				120, 130, 170, 90 };
		System.out.println(unSoloDescensosPeligroso(perfilCarrera));
	}

	// Completar
	public static boolean unSoloDescensosPeligroso(int[] perfil) {

		return false;
	}

}