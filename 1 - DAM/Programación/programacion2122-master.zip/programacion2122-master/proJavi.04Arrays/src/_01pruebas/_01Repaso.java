package _01pruebas;

public class _01Repaso {
	public static void main(String[] args) {
		int edad;
		
		int[] edades;
		edades = new int[10];
		
		double[] estaturas = new double[10];
		
		String[] diasSemana = {"lunes","martes","miérc", 
				"jueves", "viernes","sabado","domingo"};
		
	}

}
