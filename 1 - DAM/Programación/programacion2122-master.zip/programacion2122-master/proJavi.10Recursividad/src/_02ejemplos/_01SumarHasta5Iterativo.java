package _02ejemplos;

public class _01SumarHasta5Iterativo {
	public static void main(String[] args) {
		int suma = 0;
		for(int i = 1; i <= 5; i++) {
			suma += i;
		}
		System.out.println(suma);
	}
}
