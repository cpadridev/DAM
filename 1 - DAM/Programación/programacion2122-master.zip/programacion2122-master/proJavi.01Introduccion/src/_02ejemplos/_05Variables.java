package _02ejemplos;

public class _05Variables {
	public static void main(String[] args) {
		//Decarar una variable
		int edad;
		edad = 20;
		edad = 30;
		
		//Declarar variable e inicializarla
		int numero = 100;
		
		//Declarar varias variables en la misma instruccion
		int x,y = 3,z;
		
		//No se puede usar una variable que no tiene valor
		double nota1,nota2;
		//double media = (nota1 + nota2) / 2;
	}
}
