package ejercicio4;

public interface Formable {
	void formar(int horas);
}
