package ejercicio4;
public class Trabajador extends Persona{
}
