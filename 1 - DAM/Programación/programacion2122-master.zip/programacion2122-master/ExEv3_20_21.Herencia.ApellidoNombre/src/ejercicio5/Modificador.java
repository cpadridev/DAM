package ejercicio5;

public interface Modificador<T> {
	T modificar(T o); //Devuelve el elemento o modificado de alguna forma
}
