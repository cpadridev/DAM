package _02ejemplos._02animales;

public class Lobo extends Canino {
	public void saludar() {
		System.out.println("Auuuuuuuuuuu!!");
	}
}
