package _02ejemplos._02animales;

public abstract class Animal {
	public abstract void saludar();
}
