package _02ejemplos._02animales;

public class Tigre extends Felino {
	public void saludar() {
		System.out.println("GGGRRRRR!!");
	}

	@Override
	public void trepar() {
		System.out.println("Se trepar y bajar");
		
	}
}
