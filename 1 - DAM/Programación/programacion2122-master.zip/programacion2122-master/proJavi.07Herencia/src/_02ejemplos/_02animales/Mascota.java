package _02ejemplos._02animales;

public interface Mascota {
	public abstract void pasear();
	// o simplemente
	//void pasear();
}
