package _02ejemplos._02animales;

public class Perro extends Canino implements Mascota {
	public void saludar() {
		System.out.println("Guau Guau!!");
	}
	public void pasear() {
		System.out.println("Soy un perro paseando");
	}
}
