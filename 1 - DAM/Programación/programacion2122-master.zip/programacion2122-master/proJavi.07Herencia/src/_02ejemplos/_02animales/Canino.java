package _02ejemplos._02animales;

public abstract class Canino extends Animal {

}
