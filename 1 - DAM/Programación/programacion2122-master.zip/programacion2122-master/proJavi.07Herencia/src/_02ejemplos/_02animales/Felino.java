package _02ejemplos._02animales;

public abstract class Felino extends Animal {
	public abstract void trepar();
}
