package _02ejemplos._04interfaceCola;

public interface Cola {
	/*public abstract*/ void encolar(Object o);
	Object desencolar();
	int getTamanyo();
}
