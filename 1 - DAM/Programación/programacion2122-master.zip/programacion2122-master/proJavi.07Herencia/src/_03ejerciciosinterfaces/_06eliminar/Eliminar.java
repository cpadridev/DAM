package _03ejerciciosinterfaces._06eliminar;

import java.util.ArrayList;
import java.util.function.Predicate;

import _03ejerciciosinterfaces._03publicaciones.Publicacion;

public class Eliminar {
	
	//Crear una lista de publicaciones y eliminar aquellos elementos cuyo año es par
	public static void main(String[] args) {
		
	}
	
	//Implementar un metodo eliminarTodos que reciba una lista y un Predicate
	// y que elimine de la lista todos los elementos que pasan el test del predicado
	// Recordar que hay que recorrer con un iterator y borrar con el metodo remove del iterator
	public void eliminarTodos(ArrayList<Publicacion> l, Predicate<Publicacion> pred) {
		
	}

}
