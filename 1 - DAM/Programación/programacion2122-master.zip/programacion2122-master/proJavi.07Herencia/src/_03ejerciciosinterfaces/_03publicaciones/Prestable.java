package _03ejerciciosinterfaces._03publicaciones;

public interface Prestable {
	void prestar();
	void devolver();
	boolean getPrestado();
}
