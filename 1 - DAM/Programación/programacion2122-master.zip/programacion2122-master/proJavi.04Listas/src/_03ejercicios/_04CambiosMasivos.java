package _03ejercicios;

import java.util.ArrayList;

public class _04CambiosMasivos {
	
	public static void main(String[] args) {
		
	}
	
	//Método que, en la lista l, sustituya todas las apariciones de x por y
	public static void sustituir(ArrayList<String> l, String x, String y) {
		
	}
	
	//Método que, en la lista l, elimine todas las apariciones de x
	public static void eliminarTodos(ArrayList<String> l, String x) {
		
	}
	
}
