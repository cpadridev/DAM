package _01pruebas;

public class Concatenar {
	public static void main(String[] args) {
		String texto = "";
		texto = texto + 'a';
		texto = texto + 'a';
		texto = texto + 'a';
		System.out.println(texto);
		texto = texto + "pepe";
		texto = texto + 6;
		System.out.println(texto);
	}
}
