package _02ejemplos;

public class _13Bucles {
	public static void main(String[] args)  {
		
		//Mostrar del 1 al 100
		int numero = 1;
		while(numero <= 100) {
			System.out.println(numero);
			numero = numero + 1;
		}
		
	}
}
