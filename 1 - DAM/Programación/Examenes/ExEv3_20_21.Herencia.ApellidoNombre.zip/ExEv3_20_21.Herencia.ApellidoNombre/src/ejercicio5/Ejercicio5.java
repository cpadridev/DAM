package ejercicio5;

import java.util.ArrayList;
import java.util.Arrays;

public class Ejercicio5 {
	public static void main(String[] args) {
		ArrayList<String> listaPalabras = new ArrayList<>(Arrays.asList(new String[]{"casa","coche","silla","lampara"}));
		//Mostramos la lista original
		System.out.println(listaPalabras);
		//------
		
		//COMPLETAR: Convertir todas las palabras de la lista a may�sculas usando el m�todo Listas.modificarElementosLista
		
		
		//------
		
		//Volvemos a mostrar la lista
		System.out.println(listaPalabras);
		//------
	}
}
