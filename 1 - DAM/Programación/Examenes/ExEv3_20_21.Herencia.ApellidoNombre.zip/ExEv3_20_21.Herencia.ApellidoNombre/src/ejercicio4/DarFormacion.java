package ejercicio4;

public class DarFormacion {
    public static void main(String[] args) {
        Persona v[] = {
            new Desempleado(),
            new EstudianteCCFF(),
            new EstudianteCCFF(),
            new EstudianteCCFF(),
            new Desempleado(),
            new Desempleado(),
            new EstudianteCCFF(),
            new Desempleado(),
            new Desempleado(),
            new EstudianteCCFF()
        };
    }
    //Anyadir aqu� el m�todo darFormacion que se pide en el enunciado y llamalo desde el main
}
