package ejercicio4;
public class Desempleado extends Trabajador{
}
