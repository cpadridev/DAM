package ejercicio4;
public class EstudianteESO extends Estudiante{
}
