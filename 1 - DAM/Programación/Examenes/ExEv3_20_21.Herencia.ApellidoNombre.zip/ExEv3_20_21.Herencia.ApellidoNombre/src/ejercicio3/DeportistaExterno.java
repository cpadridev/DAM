package ejercicio3;

public class DeportistaExterno extends Deportista {

}
