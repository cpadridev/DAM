package ejercicio3;

public class DeportistaInterno extends Deportista{

}
