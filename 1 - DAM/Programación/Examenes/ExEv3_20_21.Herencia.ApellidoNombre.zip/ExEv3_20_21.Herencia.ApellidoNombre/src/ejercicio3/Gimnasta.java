package ejercicio3;

public class Gimnasta extends DeportistaBecado{

}
