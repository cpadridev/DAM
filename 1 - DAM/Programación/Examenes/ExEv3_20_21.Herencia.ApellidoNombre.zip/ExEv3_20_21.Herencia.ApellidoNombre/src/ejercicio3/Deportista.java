package ejercicio3;

public class Deportista {

}
