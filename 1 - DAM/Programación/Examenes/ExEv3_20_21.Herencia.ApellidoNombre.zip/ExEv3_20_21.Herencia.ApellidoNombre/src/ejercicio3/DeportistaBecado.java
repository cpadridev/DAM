package ejercicio3;

public class DeportistaBecado extends DeportistaInterno{

}
