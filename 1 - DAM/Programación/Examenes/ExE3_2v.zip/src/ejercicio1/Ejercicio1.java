package ejercicio1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Ejercicio1 {
	private static Map<String, Integer> contarPuntos(Set<Partido> partidos) {
		//Completar
		return null;
	}

	private static void mostrarGanador(Map<String, Integer> puntos) {
		//Completar
	}
	
	//-------------------------------------
	public static void main(String[] args) {
		Set<Partido> partidos = leerFichero();
		Map<String, Integer> puntos = contarPuntos(partidos);
		System.out.println(puntos);
		mostrarGanador(puntos);
	}
	private static Set<Partido> leerFichero() {
		HashSet<Partido> p = new HashSet<>();
		try (Scanner f = new Scanner(new File("resultadosLiga.txt"))) {
			while (f.hasNext()) {
				p.add(new Partido(f.next(), f.nextInt(), f.next(), f.nextInt()));
			}
		} catch (FileNotFoundException e) {
			System.err.println("Falta el fichero de resultados");
			System.err.println("PONTE EN CONTACTO CON EL PROFESOR");
			System.exit(0);
		} catch (Exception e) {
			System.err.println("Error al leer fichero de resultados");
			System.err.println("PONTE EN CONTACTO CON EL PROFESOR");
			System.exit(0);
		}
		return p;
	}
}
