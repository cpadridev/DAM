package ejercicio2;

public class ContratoMovil {
}
