package ejercicio2;

public class ContratoFijo {
}
