package ejercicio2;

public class ContratoFijoMasFibra {
}
