package ejercicio2;

public class Contrato {
}
