package ejercicio6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Ejercicio6 {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		ArrayList<String> jugadores = new ArrayList<>(Arrays.asList(new String[] {"Lea","Ana","Bob","Luis"}));
		int numeroAdivinar = new Random().nextInt(10) + 1;
		System.out.println("El numero a adivinar es: " + numeroAdivinar);
		System.out.println("Y la cola esta asi: " + jugadores + "\n");
		
		//Completar 
		
	}

}
