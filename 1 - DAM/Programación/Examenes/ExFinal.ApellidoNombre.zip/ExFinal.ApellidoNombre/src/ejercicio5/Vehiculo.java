package ejercicio5;

public class Vehiculo implements Comparable<Vehiculo> {
	private String matricula;
	private int cilindrada;
	public Vehiculo(String matricula, int cilindrada) {
		this.matricula = matricula;
		this.cilindrada= cilindrada;
	}
	
	public String getMatricula() {
		return matricula;
	}
	public int getCilindrada() {
		return cilindrada;
	}

	public int compareTo(Vehiculo v) {
		return this.matricula.compareTo(v.matricula);
	}
	
	public String toString() {
		return matricula + " - " + cilindrada + " cc.";
	}
}
