package ejercicio5;

import java.util.TreeSet;

public class Ejercicio5 {
	public static void main(String[] args) {
		TreeSet<Vehiculo> ts1 = new TreeSet<>();
		ts1.add(new Vehiculo("BCB3848", 1600));
		ts1.add(new Vehiculo("BBA3248", 1200));
		ts1.add(new Vehiculo("BBB1248", 1200));
		ts1.add(new Vehiculo("BAD4448", 1800));
	
		System.out.println("ts1: " + ts1);
		//Completar ....
		
	}
 
}
