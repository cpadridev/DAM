package ejercicio4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Ejercicio4 {
	public static void main(String[] args) {
		Map<String,Double> receta = leerFichero("receta.txt");
		Map<String,Double> nevera = leerFichero("nevera.txt");
		
		//Completar
		System.out.println("Lista de la compra: ");
		
	}
	
	private static Map<String,Double> leerFichero(String nombreFichero) {
		Map<String,Double> m = new LinkedHashMap<>();
		try (Scanner f = new Scanner(new File(nombreFichero))) {
			while (f.hasNextLine()) {
				m.put(f.next(), f.nextDouble());
			}
		} catch (FileNotFoundException e) {
			System.err.println("Falta el fichero " + nombreFichero);
			System.err.println("PONTE EN CONTACTO CON EL PROFESOR");
			System.exit(0);
		} catch (Exception e) {
			System.err.println("No se pudo leer el fichero " + nombreFichero);
			System.err.println("PONTE EN CONTACTO CON EL PROFESOR");
			System.exit(0);
		}
		return m;
	}
}
