package ejercicio3;

import java.util.ArrayList;
import java.util.NoSuchElementException;

import ejercicio2.Trabajador;

public class EquipoTrabajo {
	private ArrayList<Trabajador> miembros;

	public EquipoTrabajo() {
		miembros = new ArrayList<>();
	}
	public void anyadir(Trabajador t) {
		//Completar
	}
	
	public double salarioBrutoMedio(int anyo) {
		//Completar
		return 0;
	}
}
