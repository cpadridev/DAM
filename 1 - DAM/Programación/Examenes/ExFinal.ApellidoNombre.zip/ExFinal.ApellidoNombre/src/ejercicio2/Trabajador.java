package ejercicio2;

public class Trabajador {
	private String nombre;
	private int anyo;
	private double salarioBase;
	
	public Trabajador(String nombre, int anyo, double salarioBase) {
		this.nombre = nombre;
		this.anyo = anyo;
		this.salarioBase = salarioBase;
	}

	public String getNombre() {
		return nombre;
	}

	public int getAnyo() {
		return anyo;
	}

	public double getSalarioBase() {
		return salarioBase;
	}
	
	
}
