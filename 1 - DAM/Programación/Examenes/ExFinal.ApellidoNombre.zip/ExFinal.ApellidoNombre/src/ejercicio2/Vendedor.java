package ejercicio2;

public class Vendedor{
}
