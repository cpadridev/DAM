package ejercicio2;

public class Asalariado {
}
