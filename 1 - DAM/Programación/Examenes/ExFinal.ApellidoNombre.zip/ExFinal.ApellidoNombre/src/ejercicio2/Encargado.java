package ejercicio2;

public class Encargado {
}
