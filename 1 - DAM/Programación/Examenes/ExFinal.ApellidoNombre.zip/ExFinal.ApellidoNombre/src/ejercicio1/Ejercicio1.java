package ejercicio1;

import java.util.ArrayList;
import java.util.Arrays;

public class Ejercicio1 {
	public static void main(String[] args) {
		// Matriz con 6 alumnos y 3 asignaturas. Dos alumnos excluidos
		int[][] notas = { 
				{ 5, 9, 8, 8, 9, 1 }, 
				{ 6, 9, 6, 6, 6, 2 }, 
				{ 5, 9, 8, 8, 8, 3 } };
		String[] nombres = { "Angel", "Bea", "Carlos", "David", "Eva", "Fabio" };
		ArrayList<String> excluidos = new ArrayList<>(Arrays.asList(new String[] {"Bea","David"}));

		alumnoPremiado(notas, nombres, excluidos);
	}

	public static void alumnoPremiado(int[][] notas, String[] nombres, ArrayList<String> excluidos) {
		//Completar
	}

}