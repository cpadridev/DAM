package ejercicio2;

import java.util.ArrayList;
import java.util.Arrays;

public class Ejercicio2 {
	public static void main(String[] args) {
		ArrayList<String> aprobados = new ArrayList<>(Arrays.asList("luis","pablo","marcos","vicente","rosa","carla"));
		ArrayList<String> suspendidos = new ArrayList<>(Arrays.asList("angel","edwin","elsa"));
		ArrayList<String> recuperados = new ArrayList<>(Arrays.asList("luis","angel"));
		
		
		
		
	}
}
