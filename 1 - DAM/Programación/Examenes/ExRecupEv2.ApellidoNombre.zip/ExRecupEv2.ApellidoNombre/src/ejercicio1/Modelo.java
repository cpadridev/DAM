package ejercicio1;

public class Modelo {
    private String nombre;
    private int anyo;
    private int emisiones;
    
    public boolean aptoPlanPIVE(){
    	return false; //Sustituir por lo que indica el enunciado
    }
    public static double tasaPorEmisiones(int emisiones){
    	return 0; //Sustituir por lo que indica el enunciado
    }

    //------------------------------------------------------------------
    //------- El resto de m�todos no se pueden modificar ---------------
    public Modelo(String nombre, int anyo, int emisiones){
        this.nombre = nombre;
        this.anyo = anyo;
        this.emisiones = emisiones;
    }
    
    public boolean equals(Object o){
        if(this == o) return true;
        if(!(o instanceof Modelo)) return false;
        Modelo m = (Modelo)o;
        return anyo == m.anyo && nombre.equals(m.nombre);
    }
    
    public int getAnyo(){
    	return anyo;
    }
    public int getEmisiones(){
    	return emisiones;
    }
    public String getNombre(){
    	return nombre;
    }

    public String toString(){
        return  "Nombre: " + nombre + " - Anyo: " + anyo + " - Emisiones: " + emisiones;
    }
}
