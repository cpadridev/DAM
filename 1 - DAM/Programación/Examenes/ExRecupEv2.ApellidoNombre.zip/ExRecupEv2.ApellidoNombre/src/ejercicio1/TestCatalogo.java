package ejercicio1;

public class TestCatalogo {
	public static void main(String[] args) {
		Modelo m1 =    new Modelo("fiesta", 2012, 100);
		Modelo m2 =    new Modelo("cougar", 2013, 210);
		Modelo m3 =    new Modelo("focus", 2008, 100);
		Modelo m4 =    new Modelo("mustang", 2009, 300);
		Modelo m1bis = new Modelo("fiesta", 2012, 110);
		Catalogo c = new Catalogo();
		
		// Anyadir c�digo para probar las clases 
		
	}
}
