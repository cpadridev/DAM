package ejercicio1;

import java.util.ArrayList;

public class Catalogo {
    private String nombre;
    private ArrayList<Modelo> modelos;
    
    
    
}
