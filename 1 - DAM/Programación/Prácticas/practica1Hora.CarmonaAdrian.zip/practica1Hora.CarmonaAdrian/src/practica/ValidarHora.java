package practica;

import java.util.Scanner;

public class ValidarHora {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Introduzca una hora: ");
		String texto = sc.nextLine();

		int longitud = texto.length();
		String minutos1 = "", hora1 = "";
		int hora = 0, minutos = 0;

		// Existen ':'.
		if (texto.indexOf(':') != -1) {

			int posicion = texto.indexOf(':');
			hora1 = texto.substring(0, posicion);
			minutos1 = texto.substring(posicion + 1);

			// El usuario solo escribe ':'.
			if (hora1.equals("") && minutos1.equals("")) {
				minutos1 = "00";
				hora1 = "00";
				// El usuario solo escribe minutos.
			} else if (hora1.equals("")) {
				minutos = Integer.parseInt(minutos1);
				hora1 = "00";

				if (minutos1.length() == 1) {
					if (minutos >= 0 && minutos < 10) {
						minutos1 = "0" + minutos1;
					}
				}
				// El usuario solo escribe horas.
			} else if (minutos1.equals("")) {
				hora = Integer.parseInt(hora1);
				minutos1 = "00";

				if (hora >= 0 && hora < 10) {
					hora1 = "0" + hora1;
				}
			} else {
				hora = Integer.parseInt(hora1);
				minutos = Integer.parseInt(minutos1);

				if (hora1.length() == 1) {
					if (hora >= 0 && hora < 10) {
						hora1 = "0" + hora1;
					}
				}

				if (minutos1.length() == 1) {
					if (minutos >= 0 && minutos < 10) {
						minutos1 = "0" + minutos1;
					}
				}
			}
			// No existen ':'.
		} else {
			// Solo introduce 1 número.
			if (longitud == 1) {
				hora1 = texto.toString();
				hora1 = "0" + hora1;
				minutos1 = "00";
				// Introduce 2 números.
			} else if (longitud == 2) {
				hora = Integer.parseInt(texto);

				if (hora >= 0 && hora <= 23) {
					hora1 = texto;
					minutos1 = "00";
				} else {
					hora1 = "0" + texto.substring(0, 1);
					minutos1 = texto.substring(1) + "0";
				}
				// Introduce 3 números.
			} else if (longitud == 3) {
				hora1 = "0" + texto.substring(0, 1);
				minutos1 = texto.substring(1);
				hora = Integer.parseInt(hora1);
				minutos = Integer.parseInt(minutos1);
				// Introduce 4 números.
			} else {
				hora1 = texto.substring(0, 2);
				minutos1 = texto.substring(2);
				hora = Integer.parseInt(hora1);
				minutos = Integer.parseInt(minutos1);
			}
		}

		if (hora >= 0 && hora <= 23 && minutos >= 0 && minutos <= 59) {
			System.out.printf("La hora %s:%s es correcta", hora1, minutos1);
		} else {
			System.out.printf("La hora %s:%s es incorrecta", hora1, minutos1);
		}
	}
}
