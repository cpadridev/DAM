package utiles;

/**
 * Esta es una clase de utilidad, con metodos static. Se trata de metodos utiles
 * para trabajar con fechas.
 * 
 * @author Adrián Carmona Peña
 *
 */
public class Fechas {

	/**
	 * Determina si un año es o no bisiesto.
	 * 
	 * @param anyo el año.
	 * @return true si el año es bisiesto y false en caso contrario.
	 */
	public static boolean esBisiesto(int anyo) {
		// TODO Completar esBisiesto.
		return (anyo % 4 == 0 && anyo % 100 != 0 || anyo % 400 == 0);
	}

	/**
	 * Devuelve el número de días que tiene un mes de determinado anyo. El año es
	 * necesario porque el mes de febrero puede tener un número distinto de días
	 * dependiendo de si el año es o no bisiesto.
	 * 
	 * @param mes  El mes. Estara entre 1 y 12.
	 * @param anyo El año. Valor positivo.
	 * @return el número de días que tiene el mes.
	 */
	public static int diasDelMes(int mes, int anyo) {
		// TODO Completar diasDelMes. Habrá que llamar al método esBisiesto cuando el mes
		// sea febrero, para averiguar el número de días.
		switch (mes) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
		case 2:
			if (esBisiesto(anyo)) {
				return 29;
			} else {
				return 28;
			}
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		default:
			break;
		}
		return 0;
	}

	/**
	 * Devuelve el nombre de un mes: "Enero", "Febrero", ...
	 * 
	 * @param mes El mes del que se pide el nombre. Estará entre 1 y 12
	 * @return el nombre del mes correspondiente.
	 */
	public static String nombreDelMes(int mes) {
		// TODO completar nombreDelMes.
		switch (mes) {
		case 1:
			return "Enero";
		case 2:
			return "Febrero";
		case 3:
			return "Marzo";
		case 4:
			return "Abril";
		case 5:
			return "Mayo";
		case 6:
			return "Junio";
		case 7:
			return "Julio";
		case 8:
			return "Agosto";
		case 9:
			return "Septiemnre";
		case 10:
			return "Octubre";
		case 11:
			return "Noviembre";
		case 12:
			return "Diciembre";
		default:
			break;
		}
		return "";
	}

	/**
	 * Dado un String que contiene una fecha en formato dd/mm/aaaa devuelve un
	 * entero con el día de la fecha.
	 * 
	 * @param fecha String con formato dd/mm/aaaa. La longitud del string no tiene
	 *              por que ser 10, pues el día y el mes se pueden expresar con uno
	 *              o dos dígitos.
	 * @return el día de la fecha.
	 */
	public static int extraerDia(String fecha) {
		// TODO Completar extraerDia.
		int dia = Integer.parseInt(fecha.substring(0, 2));

		return dia;
	}

	/**
	 * Dado un String que contiene una fecha en formato dd/mm/aaaa devuelve un
	 * entero con el mes de la fecha.
	 * 
	 * @return el mes de la fecha.
	 */
	public static int extraerMes(String fecha) {
		// TODO Completar extraerMes.
		int mes = Integer.parseInt(fecha.substring(3, 5));

		return mes;
	}

	/**
	 * Dado un String que contiene una fecha en formato dd/mm/aaaa devuelve un
	 * entero con el año de la fecha.
	 * 
	 * @param fecha String con formato dd/mm/aaaa. La longitud del string no tiene
	 *              por que ser 10, pues el día y el mes se pueden expresar con uno
	 *              o dos dígitos.
	 * @return el año de la fecha.
	 */
	public static int extraerAnyo(String fecha) {
		// TODO Completar extraerAnyo
		int anyo = Integer.parseInt(fecha.substring(6, fecha.length() - 1));

		return anyo;
	}

	/**
	 * Dada una fecha expresada con tres valores (día, mes y año), devuelve si la
	 * fecha es válida o no. Para que una fecha sea correcta:
	 * - El día tiene que ser mayor que cero.
	 * - El día tiene que ser menor o igual que el numero de dias que tiene el mes.
	 * - El mes tiene que estar entre 1 y 12.
	 * - El año tiene que ser positivo.
	 * 
	 * @param dia  El dia de la fecha.
	 * @param mes  El mes de la fecha.
	 * @param anyo El año de la fecha.
	 * @return true si la fecha es válida y false si no lo es.
	 */
	public static boolean esFechaValida(int dia, int mes, int anyo) {
		// TODO Completar esFechaValida.
		// Este método tendrá que llamar a diasDelMes para averiguar cuantos
		// días tiene el mes de la fecha que nos dan y así comprobar 
		// si el día es correcto o no.
		if (dia <= diasDelMes(mes, anyo) && dia >= 1 && mes >= 1 && mes <=12 && anyo > 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Compara dos fechas para averiguar cual de ellas es la menor. Cada fecha
	 * vendrá expresada por tres valores (día, mes y año).
	 * 
	 * @param d1 Día de la primera fecha.
	 * @param m1 Mes de la primera fecha.
	 * @param a1 Año de la primera fecha.
	 * @param d2 Día de la segunda fecha.
	 * @param m2 Mes de la segunda fecha.
	 * @param a2 Año de la segunda fecha.
	 * @return 
	 *  -1 si la primera fecha es menor (anterior) que la segunda.
	 *   0 si las dos fechas son iguales.
	 *  +1 si la primera fecha es mayor (posterior) que la segunda.
	 */
	public static int compararFechas(int d1, int m1, int a1, int d2, int m2, int a2) {
		// TODO Completar compararFechas.
		int num1 = a1 * 365 + m1 * 30 + d1;
		int num2 = a2 * 365 + m2 * 30 + d2;

		if (num1 < num2)
			return -1;
		else if (num2 < num1)
			return 1;
		else
			return 0;
	}
}
