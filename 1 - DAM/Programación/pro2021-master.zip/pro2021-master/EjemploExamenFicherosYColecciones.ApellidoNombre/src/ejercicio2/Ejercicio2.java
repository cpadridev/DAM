package ejercicio2;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);

		System.out.println("Carpeta: ");
		String nombreCarpeta = tec.nextLine();
		File carpeta = new File(nombreCarpeta);
		if (!carpeta.isDirectory()) {
			System.out.println("No existe o no es una carpeta");
		} else {

			File[] contenido = carpeta.listFiles();

			ArrayList<String> carpetas = new ArrayList<>();
			ArrayList<String> archivos = new ArrayList<>();
			long tamanyoArchivos = 0;

			for (File f : contenido) {
				if (f.isDirectory()) {
					carpetas.add(f.getName());
				} else if (f.isFile()) {
					archivos.add(f.getAbsolutePath());
					tamanyoArchivos += f.length();
				}
			}

			System.out.println("Contiene " + carpetas.size() + " carpetas");
			System.out.println("Contiene " + archivos.size() + " archivos");
			System.out.println("Las carpetas son: ");
			for (String c : carpetas) {
				System.out.println("\t" + c);
			}

			System.out.println("Las carpetas son: ");
			for (String a : archivos) {
				System.out.println("\t" + a);
			}

			System.out.println("Tamaño total : " + tamanyoArchivos + " bytes");
		}

	}
}
