package ejercicio2;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio2V2 {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);

		System.out.println("Carpeta: ");
		String nombreCarpeta = tec.nextLine();
		File carpeta = new File(nombreCarpeta);
		if (!carpeta.isDirectory()) {
			System.out.println("No existe o no es una carpeta");
		} else {

			File[] carpetas = carpeta.listFiles(f->f.isDirectory());
			File[] archivos = carpeta.listFiles(f->f.isFile());
			
			System.out.println("Contiene " + carpetas.length + " carpetas");
			System.out.println("Contiene " + archivos.length + " archivos");

			System.out.println("Las carpetas son: ");
			for (File c : carpetas) {
				System.out.println("\t" + c.getName());
			}

			long tamanyoArchivos = 0;
			System.out.println("Los archivos son: ");
			for (File a : archivos) {
				System.out.println("\t" + a.getAbsolutePath());
				tamanyoArchivos += a.length();
			}

			System.out.println("Tamaño total : " + tamanyoArchivos + " bytes");
		}

	}
}
