package ejercicio1;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Garaje {
	private Set<String> permitidos;
	private Map<String, Long> dentro;
	
    
    public Garaje(){
    	permitidos = new HashSet<>();
    	dentro = new HashMap<>();
    }
    
    public void cargarPermitidos(){
    	try(Scanner f = new Scanner(new File("permitidos.txt"))){
    		while(f.hasNext()) {
    			String matricula = f.next();
    			permitidos.add(matricula);
    		}
    		
    	} catch (FileNotFoundException e) {
    		System.out.println("No se puede abrir el fichero");
		}
    }
    
    public void registrarMatricula(String matricula){
    	if(!permitidos.contains(matricula)) {
    		System.out.println("Matricula " + matricula + " no permitida");
    	} else {
    		Long instante = dentro.get(matricula);
    		if(instante == null) {
    			//El vehiculo no está. Es una entrada
    			instante = System.currentTimeMillis();
    			dentro.put(matricula, instante);
    			System.out.println("Entrada del vehiculo " + matricula + " en el instante " + instante);
    		} else {
    			long instanteSalida = System.currentTimeMillis();
    			dentro.remove(matricula);
    			System.out.println("Salida del vehiculo " + matricula + " en el instante " + instanteSalida);
    			System.out.println("Tiempo dentro: " + (instanteSalida - instante));
    		}	
    	}
    }
    
    public String toString(){
    	String res = "--- Contenido del garaje ---";
    	for(String matricula: dentro.keySet()) {
    		Long instante = dentro.get(matricula);
    		
    		res += "\nMatricula: " + matricula + " Instante de entrada " + instante ;
    	}
    	res += "\n----------------------------";
    	return res;
    	
    }
  }
