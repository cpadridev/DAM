package ejercicio3;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Ejercicio3 {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		File fMezclado = new File("alumnos.txt");
		boolean append = true;
		if(fMezclado.isFile()) {
			System.out.println("Quieres sobreescribir el fichero (s/n) ?");
			if(tec.next().toUpperCase().charAt(0) == 'S') {
				append = false;
			} else {
				append = true;
			}
		}
		
		try (
			PrintWriter fSal = new PrintWriter (new FileWriter(fMezclado,append));
			DataInputStream fnombres = new DataInputStream(new FileInputStream("nombres.dat"));
    		DataInputStream fnotas = new DataInputStream(new FileInputStream("notas.dat"));
		) {
			while(true) {
				String nombre = fnombres.readUTF();
				int nota = fnotas.readInt();
				
				fSal.println(nombre);
				fSal.println(nota);
			}
		} catch(EOFException e) {
			//Se ha terminado uno de los ficheros
			
		} catch (FileNotFoundException e) {
			System.out.println("Problema al abrir/crear fichero");
		} catch (IOException e1) {
			
		}
		
		
		
		
	}

}
