package ejercicio4;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Ejercicio4 {
	static List<String> banquillo = new LinkedList<>();
	
	public static void inicializar(){
	}
	public static void cambio(String aBanquillo, String aJugar){
	}
	public static void expulsion(String expulsado){
	}

	public static void main(String[] args) {
		inicializar();
		System.out.println("Situacion inicial: " + banquillo);
		System.out.println("-------------");
		
		System.out.println("Cambiar a jug1 por jug2");
		cambio("jug1","jug2"); // rechazado, no esta en el banquillo
		System.out.println("Banquillo: " + banquillo);
		System.out.println("-------------");

		System.out.println("Cambiar a jug6 por jug7");
		cambio("jug6","jug7"); // no est� jugando
		System.out.println("Banquillo: " + banquillo);
		System.out.println("-------------");
		
		System.out.println("Cambiar a jug1 por jug9");
		cambio("jug1","jug9"); //rechazado, cansado
		System.out.println("Banquillo: " + banquillo);
		System.out.println("-------------");

		System.out.println("Cambiar a jug1 por jug7");
		cambio ("jug1","jug7"); //aceptado
		System.out.println("Banquillo: " + banquillo);
		System.out.println("-------------");

		System.out.println("Cambiar a jug2 por jug9 ");
		cambio("jug2","jug9");  //aceptado
		System.out.println("Banquillo: " + banquillo);
		System.out.println("-------------");

		System.out.println("Expulsar a jug1");
		expulsion("jug1"); //rechazada
		System.out.println("Banquillo: " + banquillo);
		System.out.println("-------------");

		System.out.println("Expulsar a jug5");
		expulsion("jug5"); //aceptada
		System.out.println("Banquillo: " + banquillo);
	}
}
