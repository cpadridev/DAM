package _04ejerciciosinterfacesygenericidad._01conjunto;

import java.util.ArrayList;

public class Conjunto<T> implements Coleccion<T> {
	private ArrayList<T> elementos;
	
	public Conjunto() {
		this.elementos = new ArrayList<>();
	}
	
	@Override
	public String toString() {
		String result = "";
		for(T elem: elementos) {
			result += elem + " ";
		}
		return result;
	}

	@Override
	public void agregar(T elemento) {
		if(!elementos.contains(elemento)) {
			elementos.add(elemento);
		}
	}

	@Override
	public void eliminar(T elemento) {
		elementos.remove(elemento);
		
	}

	@Override
	public boolean estaVacia() {
		if(elementos.size() == 0) return true;
		else return false;
		//return elementos.size() == 0;
		//retirn elementos.isEmpty();
	}

	@Override
	public int talla() {// TODO Auto-generated method stub
		return elementos.size();
	}

	@Override
	public boolean contiene(T elemento) {
		return elementos.contains(elemento);
	}
	

}
