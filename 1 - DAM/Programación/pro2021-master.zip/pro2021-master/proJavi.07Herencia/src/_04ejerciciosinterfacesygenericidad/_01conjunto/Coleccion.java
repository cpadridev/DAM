package _04ejerciciosinterfacesygenericidad._01conjunto;

public interface Coleccion<T> {
	void agregar(T elemento);

	void eliminar(T elemento);

	boolean estaVacia();
	
	int talla();
	
	boolean contiene (T elemento);
}
