package _04ejerciciosinterfacesygenericidad._04Ordenar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import _04ejerciciosinterfacesygenericidad._03publicaciones.Libro;
import _04ejerciciosinterfacesygenericidad._03publicaciones.Publicacion;

public class Ordenar {
	public static void main(String[] args) {
		ArrayList<Publicacion> l = new ArrayList<>();
		l.add(new Libro("A1","La mansión",2020));
		l.add(new Libro("B1","La misión",2010));
		l.add(new Libro("A2","Juntos",2021));
		l.add(new Libro("B2","Desesperados",2012));
		l.add(new Libro("C1","Atracción fatal",2015));
		l.add(new Libro("C2","Plantas raras",2020));

		mostrarPorCodigo(l);
		System.out.println("---------");
		mostrarPorTitulo(l);
		System.out.println("---------");
		mostrarPorAnyo(l);
		System.out.println("---------");
		mostrarPorAnyoDecreciente(l);
		System.out.println("---------");
	}

	public static void mostrarPorCodigo(ArrayList<Publicacion> l) {
		Collections.sort(l, new ComparadorPorCodigo());
		System.out.println(l);
	}

	public static void mostrarPorTitulo(ArrayList<Publicacion> l) {
		Collections.sort(l, new Comparator<Publicacion>() {

			@Override
			public int compare(Publicacion p1, Publicacion p2) {
				return p1.getTitulo().compareTo(p2.getTitulo());
			
			}
			
		});
		System.out.println(l);
	}

	public static void mostrarPorAnyo(ArrayList<Publicacion> l) {
		Collections.sort(l,(p1,p2)-> p1.getAnyo()- p2.getAnyo());
	}

	public static void mostrarPorAnyoDecreciente(ArrayList<Publicacion> l) {
		Collections.sort(l,(p1,p2)-> {
			if(p1.getAnyo() < p2.getAnyo()) return 1;
			else if(p1.getAnyo() > p2.getAnyo()) return -1;
			else return 0;
		});
	}

}
class ComparadorPorCodigo implements Comparator<Publicacion> {

	@Override
	public int compare(Publicacion p1, Publicacion p2) {
		if(p1.getCodigo().compareTo(p2.getCodigo()) < 0) return -1;
		else if(p1.getCodigo().compareTo(p2.getCodigo()) > 0) return 1;
		else return 0;
		//return p1.getCodigo().compareTo(p2.getCodigo());
	
	}
	
}






