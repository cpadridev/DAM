package _04ejerciciosinterfacesygenericidad._03publicaciones;

import java.util.ArrayList;

public class TestPublicaciones {
	public static void main(String[] args) {
		ArrayList<Publicacion> misPublicaciones = new ArrayList<>();
		misPublicaciones.add(new Libro("a1","Introduccion java", 2020));
		misPublicaciones.add(new Dvd("a2","Consejos programación",2020,60));
		
		for(Publicacion p: misPublicaciones) {
			System.out.println(p.getTitulo());
		}
		
		int cont = 0;
		for(Publicacion p: misPublicaciones) {
			if(((Prestable)p).getPrestado()) {
				cont ++;
			}
		}
		System.out.println("Prestados: " + cont);
		
//		De otra forma
		ArrayList<Prestable> misPublicaciones2 = new ArrayList<>();
		misPublicaciones.add(new Libro("a1","Introduccion java", 2020));
		misPublicaciones.add(new Dvd("a2","Consejos programación",2020,60));
		
		for(Prestable p: misPublicaciones2) {
			//No puedo llamar a getTitulo porque no es un método
			//de prestable
			//System.out.println(p.getTitulo());
			System.out.println(((Publicacion)p).getTitulo());
		}
		
		cont = 0;
		for(Prestable p: misPublicaciones2) {
			if(p.getPrestado()) {
				cont ++;
			}
		}
		System.out.println("Prestados: " + cont);
	}

}
