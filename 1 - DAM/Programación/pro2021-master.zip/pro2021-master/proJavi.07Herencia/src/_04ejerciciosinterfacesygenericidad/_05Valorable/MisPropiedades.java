package _04ejerciciosinterfacesygenericidad._05Valorable;

public class MisPropiedades {
	// Programa de test
	public static void main(String[] args) {
		Object[] misPropiedades = { new VinoAnyejo(2000), 
				new Inmueble(70), 
				new Inmueble(70), 
				new VinoAnyejo(1998) };
		System.out.println(calcularValorTotal(misPropiedades));
	}
	// Añadir el método calcularValorTotal al que está llamando el main

	private static double calcularValorTotal(Object[] misPropiedades) {
	
		double total = 0;
		for (int i = 0; i < misPropiedades.length; i++) {
			total += ((Valorable)misPropiedades[i]).valorar();
		}	
		return total;
	}
}
