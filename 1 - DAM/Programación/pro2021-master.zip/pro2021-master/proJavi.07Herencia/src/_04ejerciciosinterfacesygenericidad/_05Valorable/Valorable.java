package _04ejerciciosinterfacesygenericidad._05Valorable;

public interface Valorable {
	double valorar();
}
