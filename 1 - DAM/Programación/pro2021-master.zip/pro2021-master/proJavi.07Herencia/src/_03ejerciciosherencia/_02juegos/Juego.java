package _03ejerciciosherencia._02juegos;

public class Juego {
	protected String titulo;
	protected String fabricante;
	protected int anyo;
	
	public Juego (String titulo, String fabricante, int anyo) {
		this.titulo = titulo;
		this.fabricante = fabricante;
		this.anyo = anyo;
	}

}
