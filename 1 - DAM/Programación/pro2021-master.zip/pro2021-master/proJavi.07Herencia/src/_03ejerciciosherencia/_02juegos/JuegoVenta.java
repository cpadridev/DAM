package _03ejerciciosherencia._02juegos;

public class JuegoVenta extends JuegoAlquilerVenta{

	public JuegoVenta(String titulo, String fabricante, int anyo, double precio, int copias) {
		super(titulo, fabricante, anyo, precio, copias);
	}
	

}
