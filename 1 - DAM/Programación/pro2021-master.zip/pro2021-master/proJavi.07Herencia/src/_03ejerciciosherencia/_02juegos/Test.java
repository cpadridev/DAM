package _03ejerciciosherencia._02juegos;

public class Test {
	public static void main(String[] args) {
		Juego j = new Juego("tit1","fab1", 2020);
		JuegoVenta jv = new JuegoVenta("tit2","fab2",2020,40,10);
		
		//JuegoAlquilerVenta jav = new JuegoAlquilerVenta("tit2","fab2",2020,40,10);
	}

}
