package _03ejerciciosherencia._08empleados;

public class VendedorAComision extends Vendedor {
	private double porcentaje;

	public VendedorAComision(String nombre, int anyo, double ventas, double porcentaje) {
		super(nombre, anyo, 1000, ventas);
		this.porcentaje = porcentaje;
	}
	
	@Override
	public double getSalarioBruto() {
		return super.getSalarioBruto() + (porcentaje * ventas / 100);
	}
	
	@Override
	public String toString() {
		return super.toString() +
				"\nPorcentaje de comisión: " + porcentaje + " %";
	}
}
