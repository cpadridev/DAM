package _03ejerciciosherencia._08empleados;

public abstract class Empleado {
	private String nombre;
	private int anyo;
	protected double salarioBase;

	public Empleado(String nombre, int anyo, double salarioBase) {
		this.nombre = nombre;
		this.anyo = anyo;
		this.salarioBase = salarioBase;
	}

	public abstract double getSalarioBruto();

	public double getSalarioNeto() {
		double sB = getSalarioBruto();
		if (sB < 1000)
			return sB * 0.9;
		else if (sB < 1500)
			return sB * 0.85;
		else
			return sB * 0.80;
	}

	public String toString() {
		return "Nombre: " + nombre + 
				"\nAlta: " + anyo + 
				"\nSalario bruto: " + getSalarioBruto() + 
				"\nSalario neto: "	+ getSalarioNeto();
	}

}
