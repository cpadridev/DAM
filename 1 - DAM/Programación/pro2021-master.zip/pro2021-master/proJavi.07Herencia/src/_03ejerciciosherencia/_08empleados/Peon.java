package _03ejerciciosherencia._08empleados;

public class Peon extends Empleado {
	private int horas;

	public Peon(String nombre, int anyo, double salarioBase, int horas) {
		super(nombre, anyo, salarioBase);
		this.horas = horas;
	}
	
	@Override
	public double getSalarioBruto() {
		return (horas/40) * salarioBase;
	}
	
	@Override
	public String toString() {
		return "Peon\n" + super.toString() +
				"\nHoras semanales: " + horas;
	}
}
