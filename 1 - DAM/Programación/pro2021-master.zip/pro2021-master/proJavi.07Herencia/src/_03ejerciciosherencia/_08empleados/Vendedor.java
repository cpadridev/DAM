package _03ejerciciosherencia._08empleados;

public class Vendedor extends Empleado {
	protected double ventas;

	public Vendedor(String nombre, int anyo, double salarioBase, double ventas) {
		super(nombre, anyo, salarioBase);
		this.ventas = ventas;
	}
	
	@Override
	public double getSalarioBruto() {
		if(ventas > 6000) return salarioBase + 100;
		else return salarioBase;
	}
	
	@Override
	public String toString() {
		return "Vendedor\n" + super.toString() +
				"\nVentas: " + ventas;
	}
}
