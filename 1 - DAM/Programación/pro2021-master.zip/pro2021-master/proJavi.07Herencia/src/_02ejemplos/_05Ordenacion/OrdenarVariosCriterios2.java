package _02ejemplos._05Ordenacion;

import java.util.Arrays;
import java.util.Comparator;

import _02ejemplos._01Instituto.Persona;

public class OrdenarVariosCriterios2 {
	
	public static void main(String[] args) {
		Persona[] v = { new Persona("555","Luisito"), 
						new Persona("111", "Juan"),
						new Persona("222", "Marga")};
		
		
		//Ordenar por nombre
		System.out.println(Arrays.toString(v));
		Arrays.sort(v, new ComparadorPorNom());
		System.out.println(Arrays.toString(v));
		
		//Ordenar por longitud del nombre
		System.out.println(Arrays.toString(v));
		Arrays.sort(v, new ComparadorPorLongitudNom());
		System.out.println(Arrays.toString(v));
	}

}
class ComparadorPorLongitudNom implements Comparator<Persona>{

	@Override
	public int compare(Persona p1, Persona p2) {
		if(p1.getNombre().length() < p2.getNombre().length()) return -1;
		else if(p1.getNombre().length() > p2.getNombre().length()) return 1;
		else return 0; 
	}

}
class ComparadorPorNom implements Comparator<Persona>{

	@Override
	public int compare(Persona p1, Persona p2) {
		return p1.getNombre().compareTo(p2.getNombre());
	}

}

