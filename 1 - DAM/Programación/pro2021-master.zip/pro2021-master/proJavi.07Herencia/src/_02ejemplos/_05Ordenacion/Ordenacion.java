package _02ejemplos._05Ordenacion;

import java.util.Comparator;

import _02ejemplos._01Instituto.Persona;

public class Ordenacion {
	
	public static void ordenar(int[] v) {
		for(int i = 0; i < v.length; i++) {
			//Busco posicion del minimo a partir 
			//de la posicion i
			int posMin = i;
			for (int j = i + 1; j < v.length; j++) {
				if(v[j] < v[posMin]) {
					posMin = j;
				}
			}
			
			//Intercambio el elemento i con el mínimo
			int aux = v[i];
			v[i] = v[posMin];
			v[posMin] = aux;
			
		}
	}
	//Ordenar array de double
	public static void ordenar(double[] v) {
		for(int i = 0; i < v.length; i++) {
			//Busco posicion del minimo a partir 
			//de la posicion i
			int posMin = i;
			for (int j = i + 1; j < v.length; j++) {
				if(v[j] < v[posMin]) {
					posMin = j;
				}
			}
			
			//Intercambio el elemento i con el mínimo
			double aux = v[i];
			v[i] = v[posMin];
			v[posMin] = aux;
			
		}
	}
	/*
	//Ordenar array de String
	public static void ordenar(String[] v) {
		for(int i = 0; i < v.length; i++) {
			//Busco posicion del minimo a partir 
			//de la posicion i
			int posMin = i;
			for (int j = i + 1; j < v.length; j++) {
				if(v[j].compareTo(v[posMin]) < 0) {
					posMin = j;
				}
			}
			
			//Intercambio el elemento i con el mínimo
			String aux = v[i];
			v[i] = v[posMin];
			v[posMin] = aux;
			
		}
	}
	//Ordenar array de String
		public static void ordenar(Persona[] v) {
			for(int i = 0; i < v.length; i++) {
				//Busco posicion del minimo a partir 
				//de la posicion i
				int posMin = i;
				for (int j = i + 1; j < v.length; j++) {
					if(v[j].compareTo(v[posMin]) < 0) {
						posMin = j;
					}
				}
				
				//Intercambio el elemento i con el mínimo
				Persona aux = v[i];
				v[i] = v[posMin];
				v[posMin] = aux;
				
			}
		}
		*/
		//Ordenar arrays de objetos
		public static void ordenar(Object[] v) {
			for(int i = 0; i < v.length; i++) {
				//Busco posicion del minimo a partir 
				//de la posicion i
				int posMin = i;
				for (int j = i + 1; j < v.length; j++) {
					if(((Comparable)v[j]).compareTo(v[posMin]) < 0) {
						posMin = j;
					}
				}
				
				//Intercambio el elemento i con el mínimo
				Object aux = v[i];
				v[i] = v[posMin];
				v[posMin] = aux;
				
			}
		}
	
		//Ordenar arrays de objetos
				public static void ordenar(Object[] v, Comparator c) {
					for(int i = 0; i < v.length; i++) {
						//Busco posicion del minimo a partir 
						//de la posicion i
						int posMin = i;
						for (int j = i + 1; j < v.length; j++) {
							if(c.compare(v[i],v[posMin]) < 0) {
								posMin = j;
							}
						}
						
						//Intercambio el elemento i con el mínimo
						Object aux = v[i];
						v[i] = v[posMin];
						v[posMin] = aux;
						
					}
				}

}
