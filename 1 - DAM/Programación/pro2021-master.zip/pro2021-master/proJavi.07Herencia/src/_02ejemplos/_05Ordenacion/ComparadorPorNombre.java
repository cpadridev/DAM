package _02ejemplos._05Ordenacion;

import java.util.Comparator;

import _02ejemplos._01Instituto.Persona;

public class ComparadorPorNombre implements Comparator<Persona>{

	@Override
	public int compare(Persona p1, Persona p2) {
		return p1.getNombre().compareTo(p2.getNombre());
	}

}
