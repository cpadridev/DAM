package _02ejemplos._05Ordenacion;

import java.util.Arrays;

import _02ejemplos._01Instituto.Persona;

public class TestOrdenacion {
	public static void main(String[] args) {
		int[] v = {5, 2, 29, 3, 40, 12,7};
		
		System.out.println(Arrays.toString(v));
		Ordenacion.ordenar(v);
		System.out.println(Arrays.toString(v));
		
        String[] v2 = {"z", "b", "n", "a"};
		
		System.out.println(Arrays.toString(v2));
		Ordenacion.ordenar(v2);
		System.out.println(Arrays.toString(v2));
		
		Persona[] v3 = {new Persona("222","Luis"),new Persona("111","Angel")};
				
		
		System.out.println(Arrays.toString(v3));
		Ordenacion.ordenar(v3);
		System.out.println(Arrays.toString(v3));
		
	}

}
