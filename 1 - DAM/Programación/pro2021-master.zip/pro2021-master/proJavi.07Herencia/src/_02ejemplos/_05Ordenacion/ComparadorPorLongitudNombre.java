package _02ejemplos._05Ordenacion;

import java.util.Comparator;

import _02ejemplos._01Instituto.Persona;

public class ComparadorPorLongitudNombre implements Comparator<Persona>{

	@Override
	public int compare(Persona p1, Persona p2) {
		if(p1.getNombre().length() < p2.getNombre().length()) return -1;
		else if(p1.getNombre().length() > p2.getNombre().length()) return 1;
		else return 0; 
	}

}
