package _02ejemplos._10GenericidadVariosTipos;

public class TestPareja {
	public static void main(String[] args) {
		Persona p1 = new Persona("Luis");
		Persona p2 = new Persona("Carmen");
		Persona p3 = new Persona("Andrés");
		
		Perro pr1 = new Perro("Bobi");
		Perro pr2 = new Perro("Laica");
		
		
		Pareja<Persona, Persona> matrimonio1 = new Pareja<>(p1,p2);
		
		Pareja<Persona,Perro> tenerPerro = new Pareja<>(p3,pr1);
		
		Pareja < Pareja<Persona,Persona>, Perro> matrimonioTienePerro =
				new Pareja<>(matrimonio1, pr2);
		
	}
}
