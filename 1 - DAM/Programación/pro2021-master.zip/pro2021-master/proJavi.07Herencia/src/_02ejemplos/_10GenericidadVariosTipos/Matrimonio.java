package _02ejemplos._10GenericidadVariosTipos;

public class Matrimonio  extends Pareja<Persona,Persona> {
	public Matrimonio(Persona p1, Persona p2) {
		super(p1,p2);
	}

}
