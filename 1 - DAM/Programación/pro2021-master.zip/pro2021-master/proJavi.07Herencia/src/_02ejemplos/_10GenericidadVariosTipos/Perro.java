package _02ejemplos._10GenericidadVariosTipos;

public class Perro {
	private String nombre;
	public Perro(String nombre) {
		this.nombre = nombre;
	}
	public String toString() {
		return nombre;
	}
}
