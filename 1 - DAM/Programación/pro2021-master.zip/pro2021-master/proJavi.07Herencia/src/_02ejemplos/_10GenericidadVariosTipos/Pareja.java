package _02ejemplos._10GenericidadVariosTipos;

public class Pareja <T,U> {
	private T miembro1;
	private U miembro2;
	
	public Pareja(T t, U u) {
		this.miembro1 = t;
		this.miembro2 = u;
	}
	public String toString() {
		return miembro1 + " - " + miembro2;
	}

}
