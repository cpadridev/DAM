package _02ejemplos._04Interfaces;

public interface Abrible {
	void abrir();
	void cerrar();

}
