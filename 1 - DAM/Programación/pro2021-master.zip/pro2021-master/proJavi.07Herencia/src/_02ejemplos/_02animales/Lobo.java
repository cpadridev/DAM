package _02ejemplos._02animales;

public class Lobo extends Canino {
	public Lobo(String nombre) {
		super(nombre);
	}

	
	public void pedirComida() {
		System.out.println("Quiero ovejas");

	}

}
