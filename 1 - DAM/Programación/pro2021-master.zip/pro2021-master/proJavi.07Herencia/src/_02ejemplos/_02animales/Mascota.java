package _02ejemplos._02animales;

public interface Mascota {
	void llevarAPelu();

}
