package _02ejemplos._02animales;

public class Tigre extends Felino {
	public Tigre(String nombre) {
		super(nombre);
	}

	
	public void pedirComida() {
		System.out.println("Quiero carne cruda");

	}

}
