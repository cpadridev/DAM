package _02ejemplos._09MetodosGenericos;

public class TestOrdenacion {
	public static void main(String[] args) {
		String[] v = {"a","b","c"};
		
		//Java deduce que el tipo T del método contiene será String
		System.out.println(Ordenacion.contiene(v, "a"));
		
		//Java deduce que el tipo T es Object
		System.out.println(Ordenacion.contiene(v, Integer.valueOf(10)));
		
		//Se puede indicar explicitamente cual es el tipo T. La instruccion
		//no compila porque no se puede llamar al metodo con un array de 
		//String y un Integer
		//System.out.println(Ordenacion.<String> contiene(v, Integer.valueOf(10) ));
	}

}
