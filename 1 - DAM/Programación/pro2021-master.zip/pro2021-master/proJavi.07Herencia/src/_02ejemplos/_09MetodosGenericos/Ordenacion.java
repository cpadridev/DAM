package _02ejemplos._09MetodosGenericos;

public class Ordenacion {

	// Devuelve el mayor de dos enteros
	public static int maximo(int a, int b) {
		if (a > b)
			return a;
		else
			return b;
	}

	// Devolver el mayor de dos objetos
	// Método generico que no usa la sintáxis de
	// genericidad
	public static Object maximo(Object a, Object b) {
		if (((Comparable) a).compareTo(b) > 0)
			return a;
		else
			return b;
	}

	// Devolver el menor de dos objetos
	// Método generico que usa la sintáxis de
	// genericidad
	public static <T extends Comparable<T>> Object minimo(T a, T b) {
		if (a.compareTo(b) < 0)
			return a;
		else
			return b;
	}
	
	//Método que dado un array, devuelve true si está ordenado
	public static boolean estaOrdenado(int[] v) {
		boolean ordenado = true;
		for (int i = 1; i < v.length && ordenado; i++) {
			if(v[i] < v[i-1]) ordenado = false;
		}
		return ordenado;
	}
	public static <T extends Comparable<T>>boolean estaOrdenado(T[] v) {
		boolean ordenado = true;
		for (int i = 1; i < v.length && ordenado; i++) {
			if(v[i].compareTo(v[i-1]) < 0) ordenado = false;
		}
		return ordenado;
	}
	
	
	//Metodo que dado un array y un elemento devuelve true si
	//el elemento está en el array
	public static boolean contiene(int[] v, int x) {
		boolean enc = false;
		for (int i = 0; i < v.length && !enc; i++) {
			if(v[i] == x) enc = true;
		}
		return enc;
	}
	
	public static  <T> boolean contiene(T[] v, T x) {
		boolean enc = false;
		for (int i = 0; i < v.length && !enc; i++) {
			if(v[i].equals(x)) enc = true;
		}
		return enc;
	}
	
	

}
