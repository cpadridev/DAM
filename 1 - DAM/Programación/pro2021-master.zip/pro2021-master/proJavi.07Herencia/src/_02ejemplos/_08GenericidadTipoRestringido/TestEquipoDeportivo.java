package _02ejemplos._08GenericidadTipoRestringido;

public class TestEquipoDeportivo {
	public static void main(String[] args) {
		EquipoDeportivo<JugadorRugbi> e1 = new EquipoDeportivo<>("Celtas");
		EquipoDeportivo<JugadorRugbi> e2 = new EquipoDeportivo<>("Lobos");
		//Solo se puede crear Equipos de deportistas: 
		//EquipoDeportivo<String> e3 = new EquipoDeportivo<>("Gatos");
		
	}
}
