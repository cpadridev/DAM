package _02ejemplos._08GenericidadTipoRestringido;

import java.util.ArrayList;

public class ListaOrdenada <T extends Comparable<T>> {

	private ArrayList<T> elementos;
	
	public ListaOrdenada() {
		this.elementos = new ArrayList<>();
	}
	
	public void add(T elem) {
		boolean enc = false;
		int pos = 0;
		for(int i = 0; i< elementos.size() && !enc; i++) {
			if(elem.compareTo(elementos.get(i)) < 0) {
				enc = true;
				pos = i;
			}
		}
		if(enc) elementos.add(pos,elem);
		else elementos.add(elem);
	}
	
	public void remove(T elem) {
		elementos.remove(elem);
	}
	public String toString() {
		return elementos.toString();
	}

}
