package _02ejemplos._08GenericidadTipoRestringido;

public class JugadorBeisbol extends Deportista{

}
