package _02ejemplos._08GenericidadTipoRestringido;

public class TestListaOrdenada {
	public static void main(String[] args) {
		ListaOrdenada<String> l1 = new ListaOrdenada<>();
		l1.add("casa");
		l1.add("arbol");
		l1.add("barco");
		System.out.println(l1);
		
		//No podemos crear una ListaOrdenada de un tipo que no implemente Comparable
		//ListaOrdenada<JugadorBeisbol> l2 = new ListaOrdenada<>();
		
		
		
	}

}
