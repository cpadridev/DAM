package _02ejemplos._08GenericidadTipoRestringido;

import java.util.ArrayList;

import _02ejemplos._07Genericidad.Futbolista;

public class EquipoDeportivo <T extends Deportista> {
	private String nombre;
	private ArrayList<T> jugadores;
	
	//Constructor
	public EquipoDeportivo (String nombre) {
		this.nombre = nombre;
		this.jugadores = new ArrayList<>();
	}
	public void fichar(T f) {
		this.jugadores.add(f);
	}
	
	public void despedir(T f) {
		this.jugadores.remove(f);
	}
	public String toString() {
		String result = "Equipo: " + nombre;
		for(T f: jugadores) {
			result += "\n" + f.toString();
		}
		return result;
	}
}
