package _02ejemplos._08GenericidadTipoRestringido;

public class Deportista {

}
