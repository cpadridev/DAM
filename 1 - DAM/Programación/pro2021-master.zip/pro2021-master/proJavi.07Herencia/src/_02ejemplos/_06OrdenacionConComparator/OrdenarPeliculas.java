package _02ejemplos._06OrdenacionConComparator;

import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Stream;

public class OrdenarPeliculas {
	public static void main(String[] args) {
		Pelicula [] pelis = {
				new Pelicula("ET", "Steven Spilberg", 1982),
				new Pelicula("Madagascar" , "Eric Darnell", 2005),
				new Pelicula("Titanic", "James Cameron", 1997)
		};
		
		// Ordenación por el criterio de compareTo de la clase pelicula
		Arrays.sort(pelis);
		System.out.println(Arrays.toString(pelis));
		
		//Ordenar por director
		Arrays.sort(pelis, new OrdenPorDirector());
		System.out.println(Arrays.toString(pelis));
		
		//Ordenar por titulo usando una clase interna
		Arrays.sort(pelis, new OrdenPorTitulo());
		System.out.println(Arrays.toString(pelis));
		
		//Ordenar por longitud  del titulo con una clase ANÓNIMA
		Arrays.sort(pelis, new Comparator<Pelicula>() {
			@Override
			public int compare (Pelicula p1, Pelicula p2) {
				return p1.getTitulo().length() - p2.getTitulo().length();
			}
		});
		System.out.println(Arrays.toString(pelis));
		
		//Ordenar por año usando expresiones lambda
		Arrays.sort(pelis,(p1,p2)-> p1.getAnyo()- p2.getAnyo());
		System.out.println(Arrays.toString(pelis));
		
		//Ordenar por anyo, a igual anyo, por titulo	
		Arrays.sort(pelis,(p1,p2)-> {
			if(p1.getAnyo() < p2.getAnyo()) return -1;
			else if(p1.getAnyo() > p2.getAnyo()) return 1;
			else return p1.getTitulo().compareTo(p2.getTitulo());
		});
			
	}

}

class OrdenPorTitulo implements Comparator<Pelicula> {

	@Override
	public int compare(Pelicula p1, Pelicula p2) {
		return p1.getTitulo().compareTo(p2.getTitulo());
	}
	
	
}




