package _02ejemplos._06OrdenacionConComparator;

import java.util.Comparator;

public class OrdenPorDirector implements Comparator<Pelicula> {

	@Override
	public int compare(Pelicula p1, Pelicula p2) {
		if(p1.getDirector().compareTo(p2.getDirector()) < 0) return -1;
		else if(p1.getDirector().compareTo(p2.getDirector()) > 0) return 1;
		return 0;
		
		//return p1.getDirector().compareTo(p2.getDirector());
	}
	
}
