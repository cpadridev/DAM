package _02ejemplos._06OrdenacionConComparator;

public class Pelicula implements Comparable <Pelicula> {
	private String titulo;
	private String director;
	private int anyo;
	
	public Pelicula(String titulo, String director, int anyo) {
		this.titulo = titulo;
		this.director = director;
		this.anyo = anyo;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getDirector() {
		return director;
	}

	public int getAnyo() {
		return anyo;
	}
	
	public String toString() {
		return titulo + " - " + director + " - " + anyo;
	}
	
	public int compareTo(Pelicula p) {
		return this.anyo - p.anyo;
	}

}
