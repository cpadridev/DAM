package _02ejemplos._07Genericidad;

public class Futbolista {
	private String nombre;
	private int goles;
	public Futbolista(String nombre) {
		this.nombre = nombre;
		this.goles = 0;
	}
	public String getNombre() {
		return nombre;
	}
	public int getGoles() {
		return goles;
	}
	
	public String toString() {
		return nombre + " - " + goles + " goles";
	}

}
