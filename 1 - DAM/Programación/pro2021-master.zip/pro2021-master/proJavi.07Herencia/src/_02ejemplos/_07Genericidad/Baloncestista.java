package _02ejemplos._07Genericidad;

public class Baloncestista {
	private String nombre;
	private double mediaPuntos;
	public Baloncestista(String nombre) {
		this.nombre = nombre;
		this.mediaPuntos = 0;
	}
	public String getNombre() {
		return nombre;
	}
	public double getMediaPuntos() {
		return mediaPuntos;
	}
	
	public String toString() {
		return nombre + " - Media puntos: " + mediaPuntos + " goles";
	}

}
