package _02ejemplos._07Genericidad;

import java.util.ArrayList;

public class TestTeam {
	public static void main(String[] args) {
		Team<Futbolista> e = new Team("1º DAM Club Futbol");
		e.fichar(new Futbolista("Rubén"));
		e.fichar(new Futbolista("Felipe"));
		e.fichar(new Futbolista("Javi"));

		//No compila porque espera recibir un Futbolista
		//e.fichar(new Baloncestista("Luis"));
		
		
		System.out.println(e);
		
		//Calcular la suma de goles
		int suma = 0;
		ArrayList<Futbolista> jugadores = e.getJugadores();
		
		for(int i = 0; i< jugadores.size(); i++) {
			suma = suma +jugadores.get(i).getGoles();
		}
		
		System.out.println("Suma de goles: " + suma);
	}

}
