package _02ejemplos._07Genericidad;

import java.util.ArrayList;

public class EquipoFutbol {
	private String nombre;
	private ArrayList<Futbolista> jugadores;
	
	public EquipoFutbol(String nombre) {
		this.nombre = nombre;
		this.jugadores = new ArrayList<>();
	}
	
	public void fichar(Futbolista f) {
		this.jugadores.add(f);
	}
	
	public void despedir(Futbolista f) {
		this.jugadores.remove(f);
	}
	public String toString() {
		String result = "Equipo: " + nombre;
		for(Futbolista f: jugadores) {
			result += "\n" + f.toString();
		}
		return result;
	}

}
