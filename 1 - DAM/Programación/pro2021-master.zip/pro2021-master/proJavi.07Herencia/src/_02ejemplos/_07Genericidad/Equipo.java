package _02ejemplos._07Genericidad;

import java.util.ArrayList;

public class Equipo {
	private String nombre;
	private ArrayList<Object> jugadores;
	
	public Equipo(String nombre) {
		this.nombre = nombre;
		this.jugadores = new ArrayList<>();
	}
	
	public void fichar(Object f) {
		this.jugadores.add(f);
	}
	
	public void despedir(Object f) {
		this.jugadores.remove(f);
	}
	public String toString() {
		String result = "Equipo: " + nombre;
		for(Object f: jugadores) {
			result += "\n" + f.toString();
		}
		return result;
	}
	
	public ArrayList<Object> getJugadores(){
		return this.jugadores;
	}

}
