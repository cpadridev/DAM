package _02ejemplos._07Genericidad;

import java.util.ArrayList;

public class EquipoBaloncesto {
	private String nombre;
	private ArrayList<Baloncestista> jugadores;
	
	public EquipoBaloncesto(String nombre) {
		this.nombre = nombre;
		this.jugadores = new ArrayList<>();
	}
	
	public void fichar(Baloncestista f) {
		this.jugadores.add(f);
	}
	
	public void despedir(Baloncestista f) {
		this.jugadores.remove(f);
	}
	public String toString() {
		String result = "Equipo: " + nombre;
		for(Baloncestista f: jugadores) {
			result += "\n" + f.toString();
		}
		return result;
	}

}
