package _02ejemplos._07Genericidad;

import java.util.ArrayList;

public class Team <T>{
	private String nombre;
	private ArrayList<T> jugadores;
	
	public Team(String nombre) {
		this.nombre = nombre;
		this.jugadores = new ArrayList<>();
	}
	
	public void fichar(T f) {
		this.jugadores.add(f);
	}
	
	public void despedir(T f) {
		this.jugadores.remove(f);
	}
	public String toString() {
		String result = "Equipo: " + nombre;
		for(T f: jugadores) {
			result += "\n" + f.toString();
		}
		return result;
	}
	
	public ArrayList<T> getJugadores(){
		return this.jugadores;
	}

}
