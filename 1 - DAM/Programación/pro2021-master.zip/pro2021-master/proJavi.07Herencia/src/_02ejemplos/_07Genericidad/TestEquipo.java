package _02ejemplos._07Genericidad;

import java.util.ArrayList;

public class TestEquipo {
	public static void main(String[] args) {
		Equipo e = new Equipo("1º DAM Club Futbol");
		e.fichar(new Futbolista("Rubén"));
		e.fichar(new Futbolista("Felipe"));
		e.fichar(new Futbolista("Javi"));
		e.fichar(new Baloncestista("Luis"));
		System.out.println(e);
		
		//Calcular la suma de goles
		int suma = 0;
		ArrayList<Object> jugadores = e.getJugadores();
		
		for(int i = 0; i< jugadores.size(); i++) {
			suma = suma +((Futbolista)jugadores.get(i)).getGoles();
		}
		
		System.out.println("Suma de goles: " + suma);
	}

}
