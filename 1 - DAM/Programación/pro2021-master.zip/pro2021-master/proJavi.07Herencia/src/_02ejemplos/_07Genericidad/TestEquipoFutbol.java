package _02ejemplos._07Genericidad;

public class TestEquipoFutbol {
	public static void main(String[] args) {
		EquipoFutbol e = new EquipoFutbol("1º DAM Club Futbol");
		e.fichar(new Futbolista("Rubén"));
		e.fichar(new Futbolista("Felipe"));
		e.fichar(new Futbolista("Javi"));
		//No se puede fichar a un baloncestista: error compilación
		//e.fichar(new Baloncestista("Luis"));
		System.out.println(e);
	}
}
