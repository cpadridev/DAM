package _04ejerciciosinterfacesygenericidad_05filtrar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.function.Predicate;

import _04ejerciciosinterfacesygenericidad._03publicaciones.Libro;
import _04ejerciciosinterfacesygenericidad._03publicaciones.Publicacion;

public class Filtrar {
	public static void main(String[] args) {
		ArrayList<Publicacion> l = new ArrayList<>();
		l.add(new Libro("A11", "La mansión", 2020));
		l.add(new Libro("B11", "La misión", 2010));
		l.add(new Libro("A2", "Juntos", 2021));
		l.add(new Libro("B2", "Desesperados", 2012));
		l.add(new Libro("C11", "Atracción fatal", 2015));
		l.add(new Libro("C2", "Plantas raras", 2020));
		
		//Mostrar las publicaciones cuyo codigo tiene una longitud par
		mostrarFiltrado(l, new LongitudPar());
		System.out.println("--------------");
		//Mostrar las publicaciones cuyo título tiene una longitud mayor que 5
		mostrarFiltrado(l,new Predicate<Publicacion> () {

			@Override
			public boolean test(Publicacion p) {
				return p.getTitulo().length() > 10;
			}
			
		});
		System.out.println("--------------");
		//Mostrar las publicaciones del año actual.
		mostrarFiltrado(l,(pub)-> 
			pub.getAnyo()== Calendar.getInstance().get(Calendar.YEAR));
		System.out.println("--------------");
		//Mostrar  las publicaciones  cuyo  año  está  entre  2000  y  2005 
		//y  cuyo  título contiene la palabra “casa”.
		mostrarFiltrado(l,(pub)->
			pub.getAnyo() >= 2000 && pub.getAnyo() <= 2005 && 
			pub.getTitulo().toLowerCase().indexOf("casa") != -1
		);
		System.out.println("--------------");
		//Mostrar las publicaciones que son libros.
		
		mostrarFiltrado(l,(pub) -> pub instanceof Libro);
		System.out.println("--------------");
		
		//Mostrar las publicaciones con título que empieza por a.
		Predicate<Publicacion> tituloEmpiezaA = (p)-> p.getTitulo().startsWith("A");
		mostrarFiltrado(l,tituloEmpiezaA);
	}
	public static <T> void mostrarFiltrado(ArrayList<T> l, Predicate<T> p) {
		for(T elemento: l) {
			if(p.test(elemento)) {
				System.out.println(elemento);
			}
		}
	}
}
class LongitudPar implements Predicate<Publicacion> {
	@Override
	public boolean test(Publicacion p) {
		if(p.getCodigo().length() % 2 == 0) return true;
		else return false;
	}
	
}







