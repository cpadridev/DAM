package ejercicio1;

public class Contenedor implements Comparable<Contenedor> {
	private String companyia;
	private int codigo;
	private double peso;
	private boolean peligroso;

	public Contenedor(String companyia, int codigo, double peso, boolean peligroso) {
		this.companyia = companyia;
		this.codigo = codigo;
		this.peso = peso;
		this.peligroso = peligroso;
	}

	public double getPeso() {
		return peso;
	}

	public boolean isPeligroso() {
		return peligroso;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Contenedor))
			return false;
		Contenedor c = (Contenedor) o;
		return this.companyia.equals(c.companyia) && this.codigo == c.codigo;
	}

	@Override
	public String toString() {
		String res = this.companyia + " - " + this.codigo + " - " + this.peso + " Kg - ";
		if (peligroso) {
			res += "Peligroso";
		} else {
			res += "No peligroso";
		}
		return res;
	}

	@Override
	public int compareTo(Contenedor c) {
		if (this.companyia.compareTo(c.companyia) < 0)
			return -1;
		else if (this.companyia.compareTo(c.companyia) > 0)
			return 1;
		else if (this.codigo < c.codigo)
			return -1;
		else if (this.codigo > c.codigo)
			return 1;
		else
			return 0;
	}

	public int compareTo2(Contenedor c) {
		if (this.companyia.compareTo(c.companyia) != 0)
			return this.companyia.compareTo(c.companyia);
		else
			return this.codigo - c.codigo;
	}
}
