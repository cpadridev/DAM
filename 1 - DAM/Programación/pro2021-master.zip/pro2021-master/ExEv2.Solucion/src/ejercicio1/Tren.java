package ejercicio1;

import java.util.ArrayList;

public class Tren {
	private String codigo;
	private boolean admitePeligrosas;
	private double pesoMaximoAdmitido;
	private ArrayList<Contenedor> contenedores;
	
	public Tren (String codigo, boolean admitePeligrosas, double pesoMaximoAdmitido) throws IllegalArgumentException{
		if(codigo == null || codigo.isEmpty() || pesoMaximoAdmitido < 0) {
			throw new IllegalArgumentException("Dato no valido");
		} 
		this.codigo = codigo;		
		this.admitePeligrosas = admitePeligrosas;
		this.pesoMaximoAdmitido = pesoMaximoAdmitido;
		contenedores = new ArrayList<>();
	}
	public double pesoTotal(){
//		double total = 0;
//		for(int i = 0; i < contenedores.size(); i++) {
//			total += contenedores.get(i).getPeso();
//		}
		double total = 0;
		for (Contenedor c: contenedores) {
			total+= c.getPeso();
		}
		return total;
	}
	public void cargar(Contenedor c) throws IllegalArgumentException{
		double actual = pesoTotal();
		if(actual + c.getPeso() > pesoMaximoAdmitido) {
			throw new IllegalArgumentException("Peso maximo superado");
		} else if(!this.admitePeligrosas && c.isPeligroso()){
			throw new IllegalArgumentException("Materias peligrosas no permitidas");
		}
		contenedores.add(c);
	}
	public boolean llevaMateriasPeligrosas(){
		if(!this.admitePeligrosas) return false;
		else {
			for(Contenedor c: contenedores) {
				if(c.isPeligroso()) return true;
			}
			return false;
		}
	}
	public boolean llevaMateriasPeligrosas2(){
		if(!this.admitePeligrosas) return false;
		else {
			boolean enc= false;
			for(int i = 0; i < contenedores.size() && !enc; i++) {
				if(contenedores.get(i).isPeligroso()) enc = true;
			}
			return enc;
		}
	}
	public String toString(){
		String res = this.codigo;
		if(this.admitePeligrosas) res += " - Admite peligrosas";
		else res += " - No admite peligrosas";
		res += " - Peso maximo: " + this.pesoMaximoAdmitido + " - Peso total: " + this.pesoTotal();
		//Informacion de los contenedores
		for(Contenedor c: contenedores) {
			res += "\n" + c.toString();
		}
		return res;
	}
}
