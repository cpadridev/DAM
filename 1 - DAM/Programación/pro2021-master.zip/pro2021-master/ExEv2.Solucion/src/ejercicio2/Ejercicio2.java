package ejercicio2;

import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) {
		int [][] matriz = {
				{ 2, 13, 21,  6,  8,  14},
				{ 7,  1,  5,  6,  9 , 88},
				{ 5,  5,  4,  5, 10,   9},
				{ 7,  1,  5,  6, -9 , 88},
				{19,  7, 13, 32, 11,  10}
		};
		
		Scanner tec = new Scanner(System.in);
		
		//Completar
		int fila,col;
		do {
			System.out.println("Fila: ");
			fila = tec.nextInt();
			System.out.println("Columna: ");
			col = tec.nextInt();
		} while(fila < 0 || col < 0 || fila >= matriz.length || col >= matriz[0].length);
		
		int sumaIzq = 0;
		for(int j = 0; j < col; j++) {
			sumaIzq += matriz[fila][j];
		}
		
		int sumaDer = 0;
		for(int j = col + 1; j < matriz[0].length; j++) {
			sumaDer += matriz[fila][j];
		}
		
		if(sumaIzq < sumaDer) System.out.println("IZQUIERDA SUMA MENOS");
		else System.out.println("DERECHA SUMA MENOS (o igual)");
	}
}