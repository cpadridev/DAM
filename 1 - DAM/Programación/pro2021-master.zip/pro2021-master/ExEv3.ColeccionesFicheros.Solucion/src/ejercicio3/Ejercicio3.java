package ejercicio3;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Ejercicio3 {
	public static void main(String[] args) {
		ArrayList<Alumno> lista = new ArrayList<>();
		// Leemos el fichero y calculamos las notas de los alumnos
		try (Scanner f = new Scanner(new File("evaluaciones.txt"))) {
			while(f.hasNext()) {
				String nombre = f.nextLine();
				double nota1= f.nextDouble();
				double nota2 = f.nextDouble();
				
				//apartado b)
				int faltas = 0;
				if(f.hasNextInt()) faltas = f.nextInt(); 
				
				//Quitar el salto de linea que deja sin leer nextInt()
				if(f.hasNextLine()) f.nextLine();
				
				
				//Calcular la nota final del alumno
				double notaFinal = (nota1 + nota2) / 2 - (0.1 * faltas);
				
				//Guardar en el ArrayList
				lista.add(new Alumno(nombre,notaFinal));
			}
		} catch (FileNotFoundException e) {
			System.out.println("No se puede abrir el fichero");
		}
		//Ordenar la lista
		Collections.sort(lista);
		
		//Escribir en el fichero binario
		try(DataOutputStream f = new DataOutputStream(new FileOutputStream("finales.dat"))){
			for(Alumno a: lista) {
				f.writeUTF(a.getNombre());
				f.writeDouble(a.getNota());
			}
		} catch (FileNotFoundException e) {
			System.out.println("No se puede abrir el fichero");
		} catch (IOException e1) {
			
		}
		
	}
}
