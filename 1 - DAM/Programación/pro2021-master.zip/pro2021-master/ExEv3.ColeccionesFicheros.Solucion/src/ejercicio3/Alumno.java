package ejercicio3;

public class Alumno implements Comparable<Alumno>{
	private String nombre;
	private double nota;
	
	public Alumno(String nombre, double nota) {
		this.nombre = nombre;
		this.nota = nota;
	}

	public String getNombre() {
		return nombre;
	}

	public double getNota() {
		return nota;
	}
	public int compareTo(Alumno a) {
		if(this.nota < a.nota) return -1;
		else if(this.nota > a.nota) return 1;
		else return this.nombre.compareTo(a.nombre);
	}
}
