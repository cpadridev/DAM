package ejercicio4;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Ejercicio4 {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		System.out.println("Carpeta 1: ");
		String nombre1 = tec.next();
		
		System.out.println("Carpeta 2: ");
		String nombre2 = tec.next();
		
		File c1 = new File(nombre1);
		File c2 = new File(nombre2);
		
		if(c1.isDirectory() && c2.isDirectory()) {
			File[] contenido1 = c1.listFiles();
			File[] contenido2 = c2.listFiles();
			List<String> carpetas1 = new ArrayList<>();
			List<String> carpetas2 = new ArrayList<>();
			List<String> ficheros1 = new ArrayList<>();
			List<String> ficheros2 = new ArrayList<>();
			for(File f: contenido1) {
				if(f.isDirectory()) carpetas1.add(f.getName());
				else if(f.isFile()) ficheros1.add(f.getName());
			}
			for(File f: contenido2) {
				if(f.isDirectory()) carpetas2.add(f.getName());
				else if(f.isFile()) ficheros2.add(f.getName());
			}
			
			//Lo mismo de otra forma
			List<String> carp1 = Arrays.asList(c1.list((f,n)-> f.isDirectory()));
			List<String> carp2 = Arrays.asList(c2.list((f,n)-> f.isDirectory()));
			List<String> fich1 = Arrays.asList(c1.list((f,n)-> f.isFile()));
			List<String> fich2 = Arrays.asList(c2.list((f,n)-> f.isFile()));
			//----------------
			
			//Carpetas comunes
			for(String c: carpetas1) {
				if(carpetas2.contains(c)) {
					System.out.println(c);
				}
			}
			
			//Ficheros no comunes
			for(String f: ficheros1) {
				if(!ficheros2.contains(f)) {
					System.out.println(f);
				}
			}
			for(String f: ficheros2) {
				if(!ficheros1.contains(f)) {
					System.out.println(f);
				}
			}
			
			
			
		} else {
			System.out.println("Tienes que indicar dos nombres de carpeta");
		}
		
		
	}
}
