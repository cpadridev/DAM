package ejercicio2;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ejercicio2 {
	public static void main(String[] args) {
		List<String> vueltas = Arrays.asList(new String[]
				{"Arturo", "Encarna", "Maria", "Fran", "Carlos", "Daniel", "Miguel", "Maria", "Encarna",
				"Maria", "Fran", "Carlos", "Daniel", "Miguel", "Maria", "Antonio", "Pablo", "Maria", "Fran", "Pablo",
				"Daniel", "Miguel", "Maria", "Encarna", "Maria", "Fran", "Carlos", "Daniel", "Miguel", "Maria",
				"Antonio", "Pablo" });
		
		Map<String,String> patrocinios = new HashMap<>();
		patrocinios.put("Arturo", "Javi");
		patrocinios.put("Encarna", "Javi");
		patrocinios.put("Maria", "Esther");
		patrocinios.put("Fran", "Esther");
		patrocinios.put("Carlos", "Monica");
		patrocinios.put("Daniel", "Monica");
		
		mostrarPagos(vueltas,patrocinios);

	}
	
	
	private static void mostrarPagos(List<String> vueltas, Map<String, String> patrocinios) {
		//Map<Profesor, Cuanto tiene que pagar>
		Map<String, Integer> pagos = new HashMap<>();
		int noPatrocinadas = 0;
		//Recorremos la lista de vueltas
		for(String alumno: vueltas) {
			//Comprobamos que profesor le patrocina
			String profesor = patrocinios.get(alumno);
			if(profesor != null) {
				//Vamos a incrementar los euros que tiene que pagar el profesor
				//en el map de pagos
				Integer euros = pagos.get(profesor);
				if(euros == null) euros = 1;
				else euros = euros+1;
				pagos.put(profesor, euros);
			} else {
				//Nadie le patrocina
				noPatrocinadas ++;
			}
		}
		
		//Mostramos resultados
		for(String profesor: pagos.keySet()) {
			System.out.println(profesor+ " tiene que pagar " + pagos.get(profesor) + " euros");
		} 
		
		System.out.println("Vueltas dadas por no patrocinados: " + noPatrocinadas);
	}

}
