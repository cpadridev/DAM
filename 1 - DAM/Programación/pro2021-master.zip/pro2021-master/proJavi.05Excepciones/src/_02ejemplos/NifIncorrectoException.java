package _02ejemplos;

public class NifIncorrectoException extends Exception {
	public NifIncorrectoException() {
		super();
	}
	public NifIncorrectoException(String msg) {
		super(msg);
	}

}
