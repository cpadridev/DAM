package _02ejemplos;

public class _04Asignacion {
	public static void main(String args[]) {
		//Declaramos una variable entera
		int edad;
		
		//Declaramos una variable real
		double estatura;
		
		//Asignamos valor a las variables
		edad = 33;
		estatura = 1.65;
		
		//No podemos usar una variable que no esté 
		//declarada
	//	peso = 82;
		
		//Podemos declarar la variable justo cuando 
		//se usa por primera vez
		int añoNacimiento = 1989;
		
		//No se puede declarar dos veces la misma variable
	//	int edad = 44;
		edad = 44;
	}
}







