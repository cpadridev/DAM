package _02ejemplos;

public class _02SalidaPantalla {
	public static void main(String args[]) {
		System.out.print("Hola");
		System.out.println ("que tal");
		System.out.println ("Yo estoy bien");
		
		//Tambien se puede mostrar el resultado
		//de una expresión aritmética
		System.out.println(12+37);
		
		//Y se puede combinar texto y expresiones
		System.out.println("El triple de 73 es" + (73 * 3));
	}
}
