package _02ejemplos;

public class _01HolaMundo {
	public static void main (String args[]) {
		System.out.println("Hola mundo!!!!");
	}
}
