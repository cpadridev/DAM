package _04recursividad;

import java.util.Arrays;
import java.util.List;

public class _01Ejemplos {
	public static void main(String[] args) {
//		System.out.println(factorial(3));
//		System.out.println(fact(3));
//		System.out.println(factorial(10));
//		System.out.println(fact(10));
		System.out.println(fibonacciMejorada(3));
		System.out.println(fibonacci(3));
//		System.out.println(sumar(6));
		
//		String frase = "lacasadelaesquina";
//		List <String> simbolos = Arrays.asList(new String[] {"l","ac","a","as"});
//		System.out.println(sePuedeEscribir(frase,simbolos));
	}
	//====== ALGUNAS SOLUCIONES RECURSIVAS SON INFINITAMENTE MÁS
		//====== SENCILLAS QUE LAS NO RECURSIVAS
		
		//Se puede escribir un texto usando un conjunto de simbolos
		//de longitud 1 o 2?
		public static boolean sePuedeEscribir(String frase, List<String> simbolos) {
			if(frase.isEmpty()) return true;
			else if(simbolos.contains(frase)) return true;
			else {
				String primero = frase.substring(0,1);
				String resto = frase.substring(1);
				if(simbolos.contains(primero) && sePuedeEscribir(resto,simbolos)) {
					return true;
				} else {
					String dosPrimeros = frase.substring(0,2);
					String restoDosPrimeros = frase.substring(2);
					if(simbolos.contains(dosPrimeros)&& sePuedeEscribir(restoDosPrimeros, simbolos)) {
						return true;
					} else {
						return false;
					}
				}
			}
			
			
			
		}
	
	//Calcular el factorial de un número
	//Versión iterativa
	public static int factorial(int num) {
		if(num == 0) return 1;
		else {
			int result = 1;
			for(int i = 1; i <= num; i++) {
				result = result * i;
			}
			return result;
		}
	} 
	
	//Versión recursiva
	public static int fact (int num) {
		if (num == 0) return 1;		     //Caso base		
		else return num * fact(num - 1); //Caso general
	}
	
	//----------Sucesión de fibonacci --------------
	public static int fibonacci (int num) {
		if(num == 1 || num == 2) return 1;
		else return fibonacci(num-1) + fibonacci(num-2);
	}
	
	//Sumar los números del 1 al n
	public static int sumar (int n) {
		if(n == 1) return 1;
		else return sumar(n-1) + n;
	}
	
	//=========================================
	// TRABAJANDO CON ARRAYS
	//=========================================
	
	//Sumar los elementos de un array
	public static int sumar(int[] v) {
		return sumar(v,0);
	}
	//Suma los elementos de v desde la posición pos hasta el final
	private static int sumar(int[]v, int pos) {
		if (pos == v.length - 1) return v[pos];
		else return v[pos] + sumar(v, pos + 1);
		
	}
	
	//Dado un array de int, devolver si contiene a x
	public static boolean contiene(int[]v, int x) {
		return contiene(v,x,0);
	}
	public static boolean contiene(int[]v, int x, int pos) {
		if(pos == v.length) return false;
		else if(v[pos] == x) return true;
		else return contiene(v,x,pos + 1);
	}
	
	public static int fibonacciMejorada(int n) {
		int v[] = new int[n+1];
		return fibonacciMejorada(n, v);
		
	}
	public static int fibonacciMejorada(int n, int[] v) {
		if(n == 0) return 1;
		else if (n == 1) return 1;
		else if(v[n] != 0) return v[n];
		else {
			v[n] = fibonacciMejorada(n-2) + fibonacciMejorada(n-1);
			return v[n];
		}
	}
	

}












