package _02ejemplos;

public class _03PostIncremento {
	public static void main(String[] args) {
		//Imprimir del 1 al 100
		int numero = 1;
		while(numero <= 100) {
			System.out.println(numero++);
		}
	}

}
