package _02ejemplos;

public class _14MultiplosDe5 {
	public static void main(String[] args) {
		//Mostrar multiplos de 5 que son menores que 
		//1000
		int multiplo = 5;
		while(multiplo < 1000) {
			System.out.println(multiplo);
			multiplo = multiplo + 5;
		}
	}
}
