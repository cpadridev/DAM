package _01pruebas;

public class _01Unicode {
	public static void main(String[] args) {
		char euro = '€';
		int codigoEuro = (int) euro;
		System.out.println(codigoEuro);
		System.out.println((int)'€');
		
	}
}
