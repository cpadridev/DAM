package _03ejercicios;

import java.io.File;

public class _01CarpetaActual {
	public static void main(String[] args) {
		File f = new File(".");
		System.out.println(f.getAbsolutePath());
		
		
	}
}
