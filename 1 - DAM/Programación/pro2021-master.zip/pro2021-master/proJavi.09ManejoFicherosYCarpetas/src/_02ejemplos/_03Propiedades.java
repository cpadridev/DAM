package _02ejemplos;

import java.io.File;
import java.util.Date;

public class _03Propiedades {
	public static void main(String[] args) {
		File f = new File("./ficherosPrueba/nombres.txt");
		File c = new File("./ficherosPrueba");
		File x = new File("./ficherosPrueba/nombres.doc");
		
		System.out.println(f.getName() + " exists : " + f.exists());
		System.out.println(c.getName() + " exists : " + c.exists());
		System.out.println(x.getName() + " exists : " + x.exists());
		System.out.println();
		
		System.out.println(f.getName() + " can write: " + f.canWrite());
		System.out.println(c.getName() + " can write: " + c.canWrite());
		System.out.println(x.getName() + " can write: " + x.canWrite());
		System.out.println();
		
		System.out.println(f.getName() + " is file: " + f.isFile());
		System.out.println(c.getName() + " is file: " + c.isFile());
		System.out.println(x.getName() + " is file: " + x.isFile());
		System.out.println();

		System.out.println(f.getName() + " is directory: " + f.isDirectory());
		System.out.println(c.getName() + " is directory: " + c.isDirectory());
		System.out.println(x.getName() + " is directory: " + x.isDirectory());
		System.out.println();
		
		System.out.println(f.getName() + " tamaño: " + f.length());
		System.out.println(c.getName() + " tamaño: " + c.length());
		System.out.println();
		
		System.out.println(f.getName() + " fecha: " + f.lastModified());
		System.out.println(c.getName() + " fecha: " + c.lastModified());
		System.out.println();
		
		System.out.println(f.getName() + " fecha: " + new Date(f.lastModified()));
		System.out.println(c.getName() + " fecha: " + new Date(c.lastModified()));
		System.out.println();

	}
}
