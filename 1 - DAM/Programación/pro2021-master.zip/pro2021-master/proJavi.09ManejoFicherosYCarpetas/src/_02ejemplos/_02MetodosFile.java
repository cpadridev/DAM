package _02ejemplos;

import java.io.File;
import java.io.IOException;

public class _02MetodosFile {
	public static void main(String[] args) {
		File f1 = new File("./ficherosPrueba/cartas/carta1.txt");
		File f2 = new File("./src/../ficherosPrueba/cartas/carta1.txt");
		
		System.out.println("tostring: " + f1);
		System.out.println("getName: " + f1.getName());
		System.out.println("getPath: " + f1.getPath());
		System.out.println("getAbsolutePath: " + f1.getAbsolutePath());
		System.out.println("getParent: " + f1.getParent());
		try {
			System.out.println("getCanonicalPath: " + f1.getCanonicalPath());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		System.out.println("-----------------");
		
		System.out.println("tostring: " + f2);
		System.out.println("getName: " + f2.getName());
		System.out.println("getPath: " + f2.getPath());
		System.out.println("getAbsolutePath: " + f2.getAbsolutePath());
		System.out.println("getParent: " + f2.getParent());
		try {
			System.out.println("getCanonicalPath: " + f2.getCanonicalPath());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
}
