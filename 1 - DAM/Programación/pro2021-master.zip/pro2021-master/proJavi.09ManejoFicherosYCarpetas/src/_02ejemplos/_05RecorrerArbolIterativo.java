package _02ejemplos;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class _05RecorrerArbolIterativo {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		System.out.println("Carpeta: ");
		String nombreCarpeta = tec.nextLine();
		File carpeta = new File(nombreCarpeta);

		if (!carpeta.isDirectory()) {
			System.out.println("No es una carpeta");
		} else {
			mostrarContenido2(carpeta);
		}
	}

	private static void mostrarContenido(File carpeta) {
		List<File> pendiente = new LinkedList<>();
		//Inicialmente lo que está pendiente de recorrer
		//es la carpeta que queremos recorrer
		pendiente.add(carpeta);
		
		//Mientras quede algo pendiente por recorrer
		while(pendiente.size() > 0) {
			//Tomamos el primer elemento pendiente
			//y lo quitamos de la lista
			File actual = pendiente.get(0);
			pendiente.remove(0);
			
			//Si es una carpeta, ponemos su contenido a la cola
			if(actual.isDirectory()) {
				File[] contenido = actual.listFiles();
				for(File c: contenido) {
					//Mostramos el elemento
					System.out.println(c.getName());
					if (c.isDirectory()) {
						pendiente.add(c);
					}
				}
			}
			
		}
	}
	private static void mostrarContenido2(File carpeta) {
		List<File> pendiente = new LinkedList<>();
		//Inicialmente lo que está pendiente de recorrer
		//es la carpeta que queremos recorrer
		pendiente.add(carpeta);
		
		//Mientras quede algo pendiente por recorrer
		while(pendiente.size() > 0) {
			//Tomamos el primer elemento pendiente
			//y lo quitamos de la lista
			File actual = pendiente.get(0);
			pendiente.remove(0);
			
			//Si es una carpeta, ponemos su contenido a la cola
			if(actual.isDirectory()) {
				File[] contenido = actual.listFiles();
				for(int i = contenido.length - 1; i >= 0; i--) {
				//for(File c: contenido) {
					//Mostramos el elemento
					System.out.println(contenido[i].getName());
					if (contenido[i].isDirectory()) {
						pendiente.add(0,contenido[i]);
					}
				}
			}
			
		}
	}

}
