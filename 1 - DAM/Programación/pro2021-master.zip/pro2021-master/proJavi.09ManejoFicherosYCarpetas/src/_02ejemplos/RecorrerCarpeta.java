package _02ejemplos;

import java.io.File;
import java.util.LinkedList;

public class RecorrerCarpeta {
	public static void main(String[] args) {
		File carpeta = new File("..");
		long tamTotal = 0;
		
		LinkedList<File> pendiente = new LinkedList<>();
		pendiente.add(carpeta);
		
		while(pendiente.size() > 0) {
			carpeta = pendiente.remove(0);
			
			
			File[] contenido = carpeta.listFiles();
			for(File f: contenido) {
				if(f.isFile()) tamTotal += f.length();
				else {
					System.out.println("Carpeta: " + f.getName());
					pendiente.add(f);
				}
			}
		}
		System.out.println("Tamaño total: " + tamTotal);
	}

}
