package _02ejemplos;

import java.io.File;

public class _01ClaseFile {
	public static void main(String[] args) {
		//Un File representa un NOMBRE de fichero o carpeta
		//que no tiene por qué ni siquiera existir
		
		//Archivo carta.txt de la carpeta actual
		File carta = new File("carta.txt");
		System.out.println(carta);
		System.out.println(carta.exists());
		
		//Archivo nombres.txt de la carpeta ficherosPrueba
		File nombres = new File("./ficherosPrueba/nombres.txt");
		System.out.println(nombres);
		System.out.println(nombres.exists());
		
		//Archivo nombres.txt de la carpeta ficherosPrueba
		File nombres2 = new File(".\\ficherosPrueba\\nombres.txt");
		System.out.println(nombres2);
		System.out.println(nombres2.exists());
		
		//Carpeta ficherosPrueba
		File carpeta = new File("./ficherosPrueba");
		File nombres3 = new File(carpeta,"nombres.txt");
		System.out.println(nombres3);
		System.out.println(nombres3.exists());
		
	}
}
