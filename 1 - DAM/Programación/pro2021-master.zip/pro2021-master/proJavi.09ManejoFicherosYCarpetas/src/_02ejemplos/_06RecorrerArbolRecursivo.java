package _02ejemplos;

import java.io.File;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFileChooser;

public class _06RecorrerArbolRecursivo {
	public static void main(String[] args) {
//		Scanner tec = new Scanner(System.in);
//		System.out.println("Carpeta: ");
//		String nombreCarpeta = tec.nextLine();
//		File carpeta = new File(nombreCarpeta);
//		
		JFileChooser chooser = new JFileChooser("."); 
	    chooser.setDialogTitle("Selecciona carpeta");
	    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    //    
	    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) { 
	      mostrarContenido(chooser.getSelectedFile(),0);
	    }

		
	}

	private static void mostrarContenido(File carpeta, int nivel) {
		File[] contenido = carpeta.listFiles();
		for(File f: contenido) {
			System.out.println(tabuladores(nivel) + f.getName());
			if(f.isDirectory()) {
				mostrarContenido(f,nivel+1);
			}
		}
		
	}
	
	private static String tabuladores(int num) {
		String res = "";
		for(int i = 0; i< num; i++) {
			res += "  ";
		}
		return res;
	}

}






