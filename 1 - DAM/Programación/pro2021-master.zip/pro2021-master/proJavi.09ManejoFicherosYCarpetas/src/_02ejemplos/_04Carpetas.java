package _02ejemplos;

import java.io.File;
import java.util.Arrays;

public class _04Carpetas {
	public static void main(String[] args) {
		File carpetaActual = new File(".");
		
		String[] contenidoCarpetaActual = carpetaActual.list();
		System.out.println(Arrays.toString(contenidoCarpetaActual));
		//Recorremos el array diciendo si se trata de fichero o carpetas
		for (int i = 0; i < contenidoCarpetaActual.length; i++) {
			
			File f = new File(carpetaActual,contenidoCarpetaActual[i]);
			//File f = new File(contenidoCarpetaActual[i]);
			if(f.isFile()) 
				System.out.println("Fichero - " + contenidoCarpetaActual[i]);
			else if(f.isDirectory()) 
				System.out.println("Carpeta - " + contenidoCarpetaActual[i]);
				
		}
		
		
		//Utilizando el metodo listFiles
		File[] contenido = carpetaActual.listFiles();
		for(File f: contenido) {
			if(f.isFile()) 
				System.out.println("Fichero - " + f.getName());
			else if(f.isDirectory()) 
				System.out.println("Carpeta - " + f.getName());
				
		}
		
		System.out.println("Ficheros que empiezan por punto");
		//Listar con filtros
		File[] empiezaPorPunto = carpetaActual.listFiles((dir,nombre)-> {
			return nombre.startsWith(".");
		});
		for(File f: empiezaPorPunto) {
			System.out.println(f);
		}
		
		System.out.println("Carpetas de la carpeta actual");
		File[] subcarpetas = carpetaActual.listFiles((x)-> x.isDirectory());
		for(File f: subcarpetas) {
			System.out.println(f);
		}
	}
}







