package ejercicio3;

public class Gimnasta extends DeportistaBecado {

	public Gimnasta(String dni, String nombre, String regimen) {
		super(dni, nombre, "gimnasia deportiva", regimen, 100);
	}
	
	@Override
	public void mostrarRecibo() {
		System.out.println("NOMBRE: " + nombre);
		System.out.println("CUOTA GRATUITA");
	}
}
