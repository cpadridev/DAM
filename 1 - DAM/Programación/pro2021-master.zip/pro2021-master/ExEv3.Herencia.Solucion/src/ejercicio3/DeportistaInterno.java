package ejercicio3;

public class DeportistaInterno extends Deportista {
	protected String regimen;

	public DeportistaInterno(String dni, String nombre, String deporte, String regimen) {
		super(dni, nombre, deporte);
		if (regimen.equals("SOLO_ALOJAMIENTO") || regimen.equals("ALOJAMIENTO+DESAYUNO")
				|| regimen.equals("PENSION_COMPLETA"))
			this.regimen = regimen;
		else
			throw new IllegalArgumentException();
	}
	@Override
	public String toString(){
		String textoPension = "Solo alojamiento";
		if(regimen.equals("ALOJAMIENTO+DESAYUNO")) textoPension = "media";
		else if(regimen.equals("PENSION_COMPLETA")) textoPension = "completa";
		return "INTERNO\n" + super.toString() + "\nPension: " + textoPension;
	}
	@Override
	public double calcularImporteAPagar() {
		if(regimen.equals("SOLO_ALOJAMIENTO")) return 300;
		if(regimen.equals("ALOJAMIENTO+DESAYUNO")) return 500;
		else return 800;
	}
}
