package ejercicio3;

public class DeportistaBecado extends DeportistaInterno{
	protected double porcentajeBeca;
	
	public DeportistaBecado(String dni, String nombre, String deporte, String regimen, double porcentajeBeca) {
		super(dni, nombre, deporte, regimen);
		this.porcentajeBeca = porcentajeBeca;
	}
	
	@Override
	public String toString(){
		return "BECADO\n" + super.toString() + "Beca: " + porcentajeBeca + " %";
	}
	@Override
	public double calcularImporteAPagar() {
		double importe = super.calcularImporteAPagar();
		return importe - importe * porcentajeBeca / 100;
	}
	
}
