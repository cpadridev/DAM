package ejercicio3;

public abstract class Deportista {
	protected String dni;
	protected String nombre;
	protected String deporte;

	public Deportista(String dni, String nombre, String deporte) {
		this.dni = dni;
		this.nombre = nombre;
		this.deporte = deporte;
	}

	@Override
	public String toString() {
		return "Nombre: " + nombre + 
				"\nDNI: " + dni + 
				"\nDeporte: " + deporte;
	}
	
	public abstract double calcularImporteAPagar();
	
	public void mostrarRecibo() {
		System.out.println("NOMBRE: " + nombre);
		System.out.println("TOTAL A PAGAR: " + calcularImporteAPagar());
	}

}
