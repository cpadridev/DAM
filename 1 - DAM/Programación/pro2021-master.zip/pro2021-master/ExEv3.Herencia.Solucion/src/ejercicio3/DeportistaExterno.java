package ejercicio3;

public class DeportistaExterno extends Deportista {
	protected double mensualidad;

	public DeportistaExterno(String dni, String nombre, String deporte, double mensualidad) {
		super(dni, nombre, deporte);
		this.mensualidad = mensualidad;
	}
	@Override
	public String toString(){
		return "EXTERNO\n" + super.toString();
	}
	@Override
	public double calcularImporteAPagar() {
		
		return mensualidad;
	}

}
