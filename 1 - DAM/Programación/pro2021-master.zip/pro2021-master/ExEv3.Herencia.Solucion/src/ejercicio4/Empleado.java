package ejercicio4;
public class Empleado extends Trabajador {

}
