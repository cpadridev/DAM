package ejercicio4;
public class EstudianteCCFF extends Estudiante implements Formable{

	@Override
	public void formar(int horas) {
		System.out.println("Estudiante de CCFF recibe formaci�n de " + horas + " horas");
		
	}
}
