package ejercicio4;
public class Estudiante extends Persona{
}
