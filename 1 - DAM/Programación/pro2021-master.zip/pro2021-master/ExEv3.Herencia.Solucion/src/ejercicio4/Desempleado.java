package ejercicio4;
public class Desempleado extends Trabajador implements Formable{
	@Override
	public void formar(int horas) {
		System.out.println("Desempleado recibe formaci�n de " + horas + " horas");
		
	}
}
