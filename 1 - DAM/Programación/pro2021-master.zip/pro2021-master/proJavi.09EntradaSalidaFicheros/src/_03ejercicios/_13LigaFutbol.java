package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.swing.JFileChooser;

public class _13LigaFutbol {
	public static void main(String[] args) throws FileNotFoundException {
		JFileChooser chooser = new JFileChooser(".");
		chooser.setDialogTitle("Selecciona carpeta");
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		
		//Creamos un Map <String, Integer> para sumar los puntos de cada equipo
		Map<String, Integer> m = new HashMap<>();
		
		if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			File carpeta = chooser.getSelectedFile();
			//Procesamos los ficheros que contenga la carpeta. Cada fichero es una jornada
			File[] ficheros = carpeta.listFiles(f->f.isFile());
			for(File f: ficheros) {
				//Añadimos al map los resultados contenidos en el fichero
				anyadirDatosJornada(f,m);
			}
			
			System.out.println(m);			
		}
	}
	private static void anyadirDatosJornada(File f, Map<String, Integer> m) throws FileNotFoundException {
		try(Scanner fent = new Scanner(f)){
			while (fent.hasNext()) {
				String local = fent.next();
				int golesLocal = fent.nextInt();
				String visitante = fent.next();
				int golesVisitante = fent.nextInt();
				
				int puntosLocal = 0, puntosVisitante = 0;
				if(golesLocal > golesVisitante) {
					puntosLocal = 3;
				} else if(golesLocal < golesVisitante) {
					puntosVisitante = 3;
				} else {
					puntosLocal = puntosVisitante = 1;
				}
				
				//Sumamos los puntos en el map
				Integer anterioresLocal = m.get(local);
				if(anterioresLocal == null) {
					m.put(local, puntosLocal);
				} else {
					m.put(local, puntosLocal + anterioresLocal);
				}
				Integer anterioresVisitante = m.get(visitante);
				if(anterioresVisitante == null) {
					m.put(visitante, puntosVisitante);
				} else {
					m.put(visitante, puntosVisitante + anterioresVisitante);
				}
				
			}
		}
		
	}

}
