package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class _10Concatenar1 {
	public static void main(String[] args) {
		try (
				Scanner f1 = new Scanner(new File("f1.txt"));
				Scanner f2 = new Scanner(new File("f2.txt"));
				PrintWriter f3 = new PrintWriter(new File("f3.txt"));

		) {
			//Volcamos f1 a f3
			while (f1.hasNextLine()) {
				f3.println(f1.nextLine());
			}
			
			//Volcamos f2 a f3
			while (f2.hasNextLine()) {
				f3.println(f2.nextLine());
			}


		} catch (FileNotFoundException e) {
			System.out.println("No se pudo abrir o crear fichero");
		}

	}
}
