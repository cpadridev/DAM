package _03ejercicios._12Jugadores;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;

public class Jugadores {
	public static void main(String[] args) {
		grabarJugadores();
		System.out.println("Antes de ordenar y quitar duplicados");
		mostrarJugadores();
		
		System.out.println("Después de ordenar y quitar duplicados");
		ordenarJugadores();
		mostrarJugadores();
		
	}
	public static void grabarJugadores() {
		try (DataOutputStream f = new DataOutputStream(
				new FileOutputStream("jugadores.bin"))){
			Scanner tec = new Scanner(System.in);
			int d;
			do {
				System.out.println("Dorsal: ");
				d = tec.nextInt();
				tec.nextLine();
				if (d != 0) {
					System.out.println("Nombre: ");
					String n = tec.nextLine();
					System.out.println("Estatura: ");
					double est = tec.nextDouble();
					
					//Escribimos en el fichero
					f.writeInt(d);
					f.writeUTF(n);
					f.writeDouble(est);
				}

			} while (d != 0);
		} catch (FileNotFoundException e) {
			System.out.println("No se puede crear el fichero");;
		} catch (IOException e) {
			
		}
	}
	
	public static void mostrarJugadores() {
		try (DataInputStream f = new DataInputStream(
				new FileInputStream("jugadores.bin"))){
			while(true) {
				System.out.println("Dorsal: " + f.readInt());
				System.out.println("Nombre: " + f.readUTF());
				System.out.println("Estatura: " + f.readDouble());
			}
		} catch (EOFException e) {
			//Se ha terminado el fichero
		} catch (FileNotFoundException e) {
			System.out.println("No se puede abrir el fichero");
		} catch (IOException e) {
			
		}
	}
	public static void ordenarJugadores() {
		TreeSet<Jugador> t = new TreeSet<>();
		
		try (DataInputStream f = new DataInputStream(
				new FileInputStream("jugadores.bin"))){
			
			while(true) {
				int d = f.readInt();
				String n = f.readUTF();
				double est = f.readDouble();
				
				
				Jugador j = new Jugador(d,n,est);
				t.add(j);
			}
			
			
		} catch (EOFException e) {
			//Se ha terminado el fichero
		} catch (FileNotFoundException e) {
			System.out.println("No se puede abrir el fichero");
		} catch (IOException e) {
			
		}
		//Vuelco los datos de nuevo al fichero
		try (DataOutputStream f = new DataOutputStream(
				new FileOutputStream("jugadores.bin"))){
			for(Jugador j: t) {
				f.writeInt(j.getDorsal());
				f.writeUTF(j.getNombre());
				f.writeDouble(j.getEstatura());
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("No se puede crear el fichero");;
		} catch (IOException e) {
			
		}
	}

}
