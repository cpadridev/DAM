package _03ejercicios;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class _04CompararFicheros {
	
	public static boolean iguales(File f1, File f2) throws FileNotFoundException, IOException {
		boolean iguales =  true;
		if(f1.length() == f2.length()) {
			//Comparar el contenido
			try (
				DataInputStream d1 = new DataInputStream(new FileInputStream(f1));
				DataInputStream d2 = new DataInputStream(new FileInputStream(f2));
			) {
				
				while(iguales) {
					if(d1.readByte() != d2.readByte()) {
						iguales = false;
					}
				}
			} catch (EOFException e) {
				//No hacemos nada
			}
			
			
		} else {
			iguales = false;
		}
		return iguales;
	}

}
