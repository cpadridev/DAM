package _03ejercicios._20ServidorSuma;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
	final static int PUERTO = 5000;

	public Servidor() {
		try {
			ServerSocket skServidor = new ServerSocket(PUERTO);
			
			System.out.println("Servidor: escuchando en el puerto " + PUERTO);
			Socket skCliente = skServidor.accept();

			
			System.out.println("Servidor: Sirviendo a un cliente");
			DataOutputStream flujoSal = new DataOutputStream(skCliente.getOutputStream());
			DataInputStream flujoEnt = new DataInputStream(skCliente.getInputStream());
			
			try (DataOutputStream f = new DataOutputStream(new FileOutputStream("ficherosPrueba/transmitido.txt"))) {
				while (true) {
					byte b = flujoEnt.readByte();
					f.writeByte(b);
				}
			} catch (EOFException e) {
				System.out.println("Fin servidor");
			}
			
			
			
			skCliente.close();
		} catch (IOException ex) {
			System.out.println(ex);
		}
	}

	public static void main(String[] args) {
		new Servidor();
	}
}