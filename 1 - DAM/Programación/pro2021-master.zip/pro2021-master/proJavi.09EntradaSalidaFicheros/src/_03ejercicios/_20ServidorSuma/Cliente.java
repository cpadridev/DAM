package _03ejercicios._20ServidorSuma;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
	final static String HOST = "localhost";
	final static int PUERTO = 5000;

	public Cliente() {
		Scanner tec = new Scanner(System.in);
		boolean terminar = false;
		while (!terminar) {
			try {
				System.out.println("Cliente: Esperando conexión con el servidor");
				Socket skCliente = new Socket(HOST, PUERTO);

				System.out.println("Cliente: Conectado al servidor");
				DataInputStream flujoEnt = new DataInputStream(skCliente.getInputStream());
				DataOutputStream flujoSal = new DataOutputStream(skCliente.getOutputStream());
				// Completar
				try (DataInputStream f = new DataInputStream(
						new FileInputStream("ficherosPrueba/datosPersonales.txt"))) {
					while (true) {
						byte b = f.readByte();
						flujoSal.writeByte(b);
					}
				} catch (FileNotFoundException e) {
					System.out.println("Fichero no encontrado");
				} catch (EOFException e) {
					System.out.println("Fin cliente");
				}

				skCliente.close();
				terminar = true;
			} catch (ConnectException ex) {
				try {
					Thread.currentThread().sleep(1000);
				} catch (InterruptedException ie) {
					System.out.println(ie);
				}
			} catch (IOException ex) {
				System.out.println(ex);
				terminar = true;
			}
		}
	}

	public static void main(String[] args) {
		new Cliente();
	}
}
