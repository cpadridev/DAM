package _03ejercicios._14LigaFutbol;

public class Puntuacion implements Comparable <Puntuacion>{
	private String equipo;
	private int puntos;
	
	public Puntuacion(String equipo, int puntos) {
		this.equipo = equipo;
		this.puntos = puntos;
	}

	@Override
	public int compareTo(Puntuacion p) {
		return p.puntos - this.puntos;
	}
	
	@Override
	public String toString() {
		return this.equipo + " - " + this.puntos + " puntos";
	}

}
