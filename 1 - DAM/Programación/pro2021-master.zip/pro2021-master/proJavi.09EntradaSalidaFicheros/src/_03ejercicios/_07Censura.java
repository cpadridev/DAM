package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class _07Censura {

	public static void aplicaCensura(String fichCensura, String fichEntrada, String fichSalida)
			throws FileNotFoundException {
		// Leemos el fichero de censura y lo pasamos a un Map
		Map<String, String> m = new HashMap<>();
		try (Scanner fCens = new Scanner(new File(fichCensura))) {
			while (fCens.hasNext()) {
				String pal1 = fCens.next();
				String pal2 = fCens.next();
				m.put(pal1, pal2);
			}
		}

		// Leer el fichero de entrada y generar el de salida

		try (Scanner fEnt = new Scanner(new File(fichEntrada));
				PrintWriter fSal = new PrintWriter(new File(fichSalida));) {
			while (fEnt.hasNext()) {
				String original = fEnt.next();
				String sustituta = m.get(original);
				if(sustituta == null) {
					fSal.print(original + " ");
				} else {
					fSal.print(sustituta + " ");
				}
			}

		}

	}

}
