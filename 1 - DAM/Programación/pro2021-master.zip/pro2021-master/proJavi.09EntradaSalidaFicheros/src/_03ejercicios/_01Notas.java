package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Scanner;

public class _01Notas {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		final String NOMBREFICHERO = "ficherosPrueba/misNotas.txt";
		final int MAXNOTAS = 20;
		int numNotas = consultarNumeroNotas(NOMBREFICHERO);

		boolean anyadir = true;
		boolean pedirNotas = true;
		if (numNotas == MAXNOTAS) {
			System.out.println("Ya están todas las notas. Quiere volver a empezar? (s/n)");
			char respuesta = tec.nextLine().toLowerCase().charAt(0);
			if (respuesta == 's') {
				numNotas = 0;
				anyadir = false;
			} else {
				pedirNotas = false;
			}
		}
		if (pedirNotas) {
			System.out.println("Hay " + numNotas + " ya introducidas");
			try (PrintWriter f = new PrintWriter(new FileWriter(NOMBREFICHERO, anyadir))) {
				double nota;
				do {
					System.out.println("Nota: ");
					nota = tec.nextDouble();
					if (nota >= 0 && nota <= 10) {
						numNotas++;
						f.println(nota);
					}
				} while (nota >= 0 && nota <= 10 && numNotas < MAXNOTAS);

			} catch (IOException e) {
				System.out.println("No se pudo escribir el fichero");
			}
		}

	}

	private static int consultarNumeroNotas(String fichero) {
		int numNotas = 0;
		try (Scanner f = new Scanner(new File(fichero)).useLocale(Locale.US)) {
			while (f.hasNextDouble()) {
				f.nextDouble();
				numNotas++;
			}
		} catch (FileNotFoundException e) {
			// El fichero no existe, pero eso no es un
			// error. Solo significa que hay cero notas.
			// Todavía no se ha ejecutado el programa
			// ninguna vez
		}

		return numNotas;
	}
}
