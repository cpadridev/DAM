package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class _11Concatenar2 {
	public static void main(String[] args) {
		try (
			PrintWriter f1 = new PrintWriter(new FileWriter("f1.txt", true));
			Scanner f2 = new Scanner(new File("f2.txt"));
		) {
					
			//Volcamos f2 a f1
			while (f2.hasNextLine()) {
				f1.println(f2.nextLine());
			}


		} catch (FileNotFoundException e) {
			System.out.println("No se pudo abrir o crear fichero");
		} catch (IOException e) {
			System.out.println("No se pudo abrir o crear fichero");
		}

	}
}
