package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class _22RENUMAceptaElReto {
	public static void main(String[] args) {
		Map<Integer,Integer> m = new HashMap<>();
		
		try (Scanner f = new Scanner(new File("ficherosPrueba/programaEntrada.txt"))) {
			int nuevoNum = 10;
			while(f.hasNextInt()) {
				int num = f.nextInt();
				f.nextLine(); //Saltamos el resto de linea
				m.put(num, nuevoNum);
				nuevoNum += 10;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try (
			Scanner fEnt = new Scanner(new File("ficherosPrueba/programaEntrada.txt"));
			PrintWriter fSal = new PrintWriter(new File("ficherosPrueba/programaSalida.txt"));
		){
			while(fEnt.hasNextInt()) {
				int numLinea = fEnt.nextInt();
				
				
				String instr = fEnt.next();
				if(instr.equals("GOTO") || instr.equals("GOSUB")) {
					int salto = fEnt.nextInt();
					
					fSal.println(m.get(numLinea) + " " + instr + " " + m.get(salto) );	
				} else {
					fSal.println(m.get(numLinea) + " " + instr);
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
}
