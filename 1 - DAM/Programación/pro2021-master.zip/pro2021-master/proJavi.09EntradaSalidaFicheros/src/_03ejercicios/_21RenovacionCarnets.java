package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class _21RenovacionCarnets {
	public static void main(String[] args) {
		Map<String, Integer> anterior = new HashMap<>();
		Set<String> actual = new HashSet<>();

		try (Scanner f = new Scanner(new File("ficherosPrueba/matricula2020.txt"));
				Scanner f2 = new Scanner(new File("ficherosPrueba/matricula2021.txt"))) {
			while (f.hasNext()) {
				String nombre = f.nextLine();
				int anyo = f.nextInt();
				if (f.hasNextLine())
					f.nextLine();

				anterior.put(nombre, anyo);
			}
			while (f2.hasNext()) {
				String nombre = f2.nextLine();
				actual.add(nombre);
			}
			
			
			//Carnets a crear
			List<String> crear = new ArrayList<>();
			
			System.out.println(anterior);
			System.out.println(actual);
			for(String nombre: actual) {
				//Buscamos el nombre en la matricula anterior
				Integer anyo = anterior.get(nombre);
//				if(anyo == null) {
//					//Es un alumno nuevo
//					crear.add(nombre);
//				} else {
//					if(anyo < 2017) {
//						//Le ha caducado el carnet
//						crear.add(nombre);
//					}
//				}
				if(anyo == null || anyo < 2017) {
					crear.add(nombre);
				}
			}
			//Carnets a eliminar
			Set<String> setEliminar = anterior.keySet();
			setEliminar.removeAll(actual);
			List<String> eliminar = new ArrayList<>(setEliminar);
			System.out.println("Eliminar: " + eliminar);
			
			System.out.println("Crear: " + crear);
			
			
			
		} catch (FileNotFoundException e) {
			System.out.println("No se pudo abrir el fichero");
		}

	}

}
