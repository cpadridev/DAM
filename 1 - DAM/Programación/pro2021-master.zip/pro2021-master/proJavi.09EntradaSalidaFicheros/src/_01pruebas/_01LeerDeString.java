package _01pruebas;

import java.util.Scanner;

public class _01LeerDeString {
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		System.out.println("Introduce una linea con edades: ");
		String edades = tec.nextLine();
		
		//Sumar las edades
		int suma = 0;
		Scanner s = new Scanner(edades);
		while(s.hasNext()) {
			int edad = s.nextInt();
			suma += edad;
		}
		System.out.println(suma);
	}

}
