package _02ejemplos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class _08ConvertirAMayusculas {
	// Dado un fichero de texto (origen), cuyo nombre indica el usuario
	// crea otro fichero de texto (destino), cuyo nombre indica el usuario
	// El fichero destino será igual que el origen pero con todo el texto en
	// mayúsculas

	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		System.out.println("Nombre fichero origen: ");
		String nombreOrigen = tec.nextLine();

		System.out.println("Nombre fichero destino: ");
		String nombreDestino = tec.nextLine();

		try (
				Scanner fo = new Scanner(new File("ficherosPrueba/" + nombreOrigen));
			PrintWriter fs = new PrintWriter(new File("ficherosPrueba/" + nombreDestino))
		) {

			while (fo.hasNextLine()) {
				String linea = fo.nextLine();
				fs.println(linea.toUpperCase());
			}

		} catch (FileNotFoundException e) {
			System.out.println("El fichero no se pudo abrir");
		}
		// Si queremos distinguir qué fichero no se ha podido abrir
		// tenemos que hacer dos bloques try catch
		try (Scanner fo = new Scanner(new File("ficherosPrueba/" + nombreOrigen))) {
			try (PrintWriter fs = new PrintWriter(new File("ficherosPrueba/" + nombreDestino))) {
				while (fo.hasNextLine()) {
					String linea = fo.nextLine();
					fs.println(linea.toUpperCase());
				}
			} catch (FileNotFoundException e) {
				System.out.println("El fichero origen no se pudo abrir");
			}
		} catch (FileNotFoundException e) {
			System.out.println("El fichero destino no se pudo crear");
		}
		
		//Sin usar un try-catch with resources
		Scanner fo = null;
		PrintWriter fs = null;
		try {
			fo = new Scanner(new File("ficherosPrueba/" + nombreOrigen));
			fs = new PrintWriter(new File("ficherosPrueba/" + nombreDestino));
			while (fo.hasNextLine()) {
				//String linea = fo.nextLine();
				//fs.println(linea.toUpperCase());
				fs.println(fo.nextLine().toUpperCase());
			}
		} catch (FileNotFoundException e) {
			System.out.println("El fichero no se pudo abrir");
		} finally {
			if(fo != null) fo.close();
			if(fs != null) fs.close();
		}
	}

}
