package _02ejemplos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;
import java.util.Scanner;

public class _06LeerDatosPersonales {
	//Del fichero de datos personales mostrar:
	// - todos los nombres
	// - la edad media
	
	public static void main(String[] args) {
		try(Scanner f = new Scanner(new File("ficherosPrueba/datosPersonales.txt")).useLocale(Locale.US)) {
			
			int sumaEdades = 0;
			int cont = 0;
			while(f.hasNext()) {
				String nombre = f.nextLine();
				System.out.println(nombre);
				
				int edad = f.nextInt();
				sumaEdades += edad;
				cont++;
				
				//leemos l estatura
				f.nextDouble(); f.nextLine();
			}
			
			System.out.println("Edad media " + (sumaEdades / (double) cont));
		} catch (FileNotFoundException e) {
			System.out.println("Fichero no existe o no se puede abrir");
		} 
		
		
	}

}
