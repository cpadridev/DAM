package _02ejemplos;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class _11EscribirBinarioNumeros {
	public static void main(String[] args) {
		
		DataOutputStream f = null;
		
		try {
			f = new DataOutputStream(new FileOutputStream("ficherosPrueba/numeros.dat"));
			for(int i = 1; i<= 100; i++) {
				f.writeInt(i);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("No se pudo crear el fichero");
		} catch (IOException e) {
			System.out.println("Error de escritura");
		} finally {
			if(f != null)
				try {
					f.close();
					System.out.println("Fin");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
	}
}
