package _02ejemplos;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class _03TryCatchWithResources {
	//Programa que escribe en un fichero de texto
	//los números del 1 al 100
	public static void main(String[] args) {
		
		//Para escribir ficheros de texto
		//usamos la clase PrintWriter
		
		
		try (PrintWriter f = new PrintWriter("ficherosPrueba/numeros1a100.txt")) {
			//Usamos (escribimos) el fichero
			for(int i = 1; i <= 100; i++) {
				f.println(i);
			}
			System.out.println("Finalizado");
			
			
		} catch (FileNotFoundException e) {
			System.out.println("No se puede crear el fichero o "
					+ "el fichero ya existe y no se puede reescribir");
		}
		
	}
}
