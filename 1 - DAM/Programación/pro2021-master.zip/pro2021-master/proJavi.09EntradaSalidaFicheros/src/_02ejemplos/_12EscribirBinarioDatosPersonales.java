package _02ejemplos;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class _12EscribirBinarioDatosPersonales {
	public static void main(String[] args) {
		try (DataOutputStream f = new DataOutputStream(new FileOutputStream("ficherosPrueba/datospersonales.dat"))) {

			try {
				Scanner tec = new Scanner(System.in);
				String nombre;
				do {
					System.out.println("Nombre: ");
					nombre = tec.nextLine();
					if (!nombre.isEmpty()) {
						System.out.println("Edad: ");
						int edad = tec.nextInt();

						System.out.println("Estatura: ");
						double estatura = tec.nextDouble();
						tec.nextLine();

						// Escribimos los datos en el fichero
						f.writeUTF(nombre);
						f.writeInt(edad);
						f.writeDouble(estatura);

					}
				} while (!nombre.isEmpty());

			} catch (IOException e) {
				System.out.println("Error de escritura");
			}

		} catch (FileNotFoundException e) {
			System.out.println("No se pudo crear el fichero");
		} catch (IOException e) {
			// Error al cerrar el fichero
			e.printStackTrace();
		}
	}
}
