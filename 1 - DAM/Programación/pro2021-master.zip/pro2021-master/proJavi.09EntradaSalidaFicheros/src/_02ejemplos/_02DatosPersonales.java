package _02ejemplos;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class _02DatosPersonales {
	public static void main(String[] args) {
		PrintWriter f = null;
		try {
			f = new PrintWriter("ficherosPrueba/datosPersonales.txt");

			Scanner tec = new Scanner(System.in);
			String nombre;
			do {
				System.out.println("Nombre: ");
				nombre = tec.nextLine();
				if (!nombre.isEmpty()) {
					System.out.println("Edad: ");
					int edad = tec.nextInt();

					System.out.println("Estatura: ");
					double estatura = tec.nextDouble();
					tec.nextLine();
					
					//Escribimos los datos en el fichero
					f.println(nombre);
					f.println(edad);
					f.println(estatura);

				}
			} while (!nombre.isEmpty());

		} catch (FileNotFoundException e) {
			System.out.println("El fichero no se ha podido abrir o crear");
		} finally {
			if (f!= null) f.close();
		}
	}

}
