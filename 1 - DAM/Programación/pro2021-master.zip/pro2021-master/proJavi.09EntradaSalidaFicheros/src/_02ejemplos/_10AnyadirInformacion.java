package _02ejemplos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class _10AnyadirInformacion {
	//Programa que pide nombres al usuario y los va añadiendo
	//al fichero nombres.txt
	
	public static void main(String[] args) {
		Scanner tec = new Scanner(System.in);
		
		PrintWriter f = null;
		FileWriter fw = null;
		try {
			fw = new FileWriter("ficherosPrueba/nombres.txt", true);
			f = new PrintWriter(fw);
			// o fw = new FileWriter(new File("ficherosPrueba/nombres.txt")));
			String nombre;
			do {
				System.out.println("Nombre: ");
				nombre = tec.nextLine();
				if(!nombre.isEmpty()) {
					f.println(nombre);
				}
			} while (!nombre.isEmpty());
		} catch (IOException e) {
			System.out.println("Error al abrir o crear el fichero ");
		} finally {
			if(f != null) f.close();
		}
		
		
		
		//Lo habitual es usar solo una variable del tipo que tiene el método que queremos
		//usar.
		//PrintWriter f = new PrintWriter(new FileWriter("ficherosPrueba/nombres.txt"),true);
	}
	
	

}
