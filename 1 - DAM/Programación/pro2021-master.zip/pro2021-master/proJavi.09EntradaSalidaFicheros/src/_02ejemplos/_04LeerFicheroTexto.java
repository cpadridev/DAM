package _02ejemplos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class _04LeerFicheroTexto {
	
	//Sumar los números del fichero numeros1a100.txt
	public static void main(String[] args) {
		//Para leer fichero de texto
		//usamos la clase Scanner
		
		Scanner f = null;
		try {
			f = new Scanner(new File("ficherosPrueba/numeros1a100.txt"));
			 int suma = 0;
			while(f.hasNext()) {
				int num = f.nextInt();
				suma += num;
			}
			System.out.println("Suma: " + suma);
			
		} catch (FileNotFoundException e) {
			System.out.println("El fichero no existe o existe y no se puede abrir");
		} finally {
			if(f != null) {
				f.close();
			}
		}
		
		
	}
}
