package _02ejemplos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class _07LeerSoloEnteros {

	// Supongamos que un fichero de texto contiene
	// numeros enteros mezclados con otros tipos ocasionalmente
	// y queremos leer solo los enteros
	public static void main(String[] args) {

		// Calculamos la suma de los enteros
		try (Scanner f = new Scanner(new File("ficherosPrueba/datosMezclados.txt"))) {
			int suma = 0;
			while (f.hasNext()) {
				try {
					int num = f.nextInt();
					suma += num;
				} catch (InputMismatchException e) {
					System.out.println("Saltamos " + f.next());
				}
			}
			System.out.println("Suma: " + suma);
		} catch (FileNotFoundException e) {
			System.out.println("El fichero no existe o no se puede abrir");
		}

		// Calculamos la suma de los enteros
		try (Scanner f = new Scanner(new File("ficherosPrueba/datosMezclados.txt"))) {
			int suma = 0;
			while (f.hasNext()) {
				if(f.hasNextInt()) {
					int num = f.nextInt();
					suma += num;
				} else {
					f.next();
				}
			}
			System.out.println("Suma: " + suma);
		} catch (FileNotFoundException e) {
			System.out.println("El fichero no existe o no se puede abrir");
		}

	}

}
