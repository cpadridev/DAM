package _02ejemplos;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class _13LeerBinarioNumeros {
	
	public static void main(String[] args) {
		DataInputStream f = null;
		int suma = 0;
		try {
			f = new DataInputStream(new FileInputStream("ficherosPrueba/numeros.dat"));
			
			while(true) {
				int num = f.readInt();
				suma += num;
			}
			//System.out.println("Suma: " + suma);
			
		} catch (EOFException e ) {
			System.out.println("SUMA: " + suma);
			System.out.println("El programa ha terminado con normalidad");
		} catch (FileNotFoundException e) {
			System.out.println("No se pudo abrir el fichero");
		} catch (IOException e) {
			//e.printStackTrace();
			System.out.println("Error de lectura");
		} finally {
			try {
				f.close();
			} catch (IOException e) {
				// Problema al cerrar el fichero
				e.printStackTrace();
			}
		}
	}
}
