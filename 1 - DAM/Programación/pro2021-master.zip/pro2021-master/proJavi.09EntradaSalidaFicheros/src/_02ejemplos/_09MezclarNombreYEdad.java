package _02ejemplos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class _09MezclarNombreYEdad {
	//Dado un fichero con nombres, cada nombre en una linea - nombres.txt
	// y otro con edades - edades.txt
	
	//Crear un tercer fichero - mezclado.txt - que contenga 
	// nombre
	// edad
	// nombre
	// edad
	// ...
	
	public static void main(String[] args) {
		
		try(
			Scanner edades = new Scanner(new File("ficherosPrueba/edades.txt"));	
			Scanner nombres = new Scanner(new File("ficherosPrueba/nombres.txt"));	
			PrintWriter mezclado = new PrintWriter(new File("ficherosPrueba/mezclado.txt"));	
		){
			while(edades.hasNext() && nombres.hasNextLine()) {
				String nombre = nombres.nextLine();
				int edad = edades.nextInt();
				
				mezclado.println(nombre);
				mezclado.println(edad);
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("Problema al abrir alguno de los ficheros");
		}
		
	}

}
