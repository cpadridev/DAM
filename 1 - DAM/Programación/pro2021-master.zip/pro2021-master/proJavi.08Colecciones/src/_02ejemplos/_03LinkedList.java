package _02ejemplos;

import java.util.LinkedList;

public class _03LinkedList {
	public static void main(String[] args) {
		LinkedList<Integer> l1 = new LinkedList<>();
		// Añadiendo al final del arraylist
		long t1 = System.currentTimeMillis();

		for (int i = 1; i < 10000000; i++) {
			l1.add(i);
		}

		long t2 = System.currentTimeMillis();
		System.out.println(t2 - t1);

		// Insertando al principio
		LinkedList<Integer> l2 = new LinkedList<>();

		t1 = System.currentTimeMillis();

		for (int i = 1; i < 10000000; i++) {
			l2.add(0, i);
		}

		t2 = System.currentTimeMillis();
		System.out.println(t2 - t1);

		// Insertando al principio
		LinkedList<Integer> l3 = new LinkedList<>();

		t1 = System.currentTimeMillis();

		for (int i = 1; i < 10000000; i++) {
			l3.add(l3.size()/2, i);
		}

		t2 = System.currentTimeMillis();
		System.out.println(t2 - t1);

	}

}
