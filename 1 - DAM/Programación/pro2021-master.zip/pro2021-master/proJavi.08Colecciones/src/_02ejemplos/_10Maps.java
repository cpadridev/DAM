package _02ejemplos;

import java.util.LinkedHashMap;
import java.util.Map;

public class _10Maps {
	public static void main(String[] args) {
		
		//Los Map permiten almacenar parejas (clave, valor)
		Map<String, String> traducciones = new LinkedHashMap<>();
		
		traducciones.put("casa", "house");
		traducciones.put("fuego", "fire");
		System.out.println(traducciones);
		
		//La clave no puede repetirse. Si añadimos una pareja con
		//una clave que ya existe, sobreescribe el valor asociado
		//y devuelve el que había
		String antigua = traducciones.put("casa", "home");
		System.out.println("Antigua: " + antigua);
		System.out.println(traducciones);
		
		//Averiguar cual es el valor asociado a una clave
		
		System.out.println(traducciones.get("casa"));
		System.out.println(traducciones.get("armario")); //devuelve null
		
		//Averiguar si una clave está en el Map
		System.out.println(traducciones.containsKey("casa"));
		System.out.println(traducciones.containsKey("armario"));
		
		//Averiguar si un valor está en el Map
		System.out.println(traducciones.containsValue("home"));
		System.out.println(traducciones.containsValue("chair"));
		
		
		
	}

}
