package _02ejemplos;

import java.util.ArrayList;
import java.util.HashSet;

public class _01ListVsSet {
	public static void main(String[] args) {
		ArrayList<String> l1 = new ArrayList<>();
		
		//Añadir elementos al final
		l1.add("casa");
		l1.add("coche");
		l1.add("moto");
		l1.add("barco");
		
		//Añadir duplicados
		l1.add("casa");
		
		//Insertar en una posicion
		l1.add(1,"camión");
		
		//Eliminar por contenido
		l1.remove("moto");
		//Eliminar por posicion
		l1.remove(2);
		
		System.out.println(l1);
		
		HashSet<String> s1 = new HashSet<>();
		
		//Añadir elementos al final
		s1.add("casa");
		s1.add("coche");
		s1.add("moto");
		s1.add("barco");
				
		//Añadir duplicados
		s1.add("casa");
		System.out.println(s1);
		
		//Insertar en una posicion:	 NO DEFINIDO
		//s1.add(1,"camión");
		
		//Eliminar por contenido
		s1.remove("moto");
		System.out.println(s1);
		
		//Eliminar por posicion: NO DEFINIDO
		//s1.remove(2);
		
		
	}
}
