package _02ejemplos._08ImportanciaHashCode;

public class Alumno {
	private String dni;
	private String nombre;
	
	public Alumno(String dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
	}

	public String toString() {
		return dni + " - " + nombre;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Alumno other = (Alumno) obj;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		return true;
	}
	
//	public int hashCode() {
//		//return 1;
//		//return Integer.parseInt(dni);
//		return this.dni.hashCode();
//	}
//	
//	public boolean equals(Object o) {
//		return this.dni.equals(((Alumno)o).dni);
//	}
}
