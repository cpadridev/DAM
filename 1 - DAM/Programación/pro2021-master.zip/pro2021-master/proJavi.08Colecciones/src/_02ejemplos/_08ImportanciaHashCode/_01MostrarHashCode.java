package _02ejemplos._08ImportanciaHashCode;

import java.util.HashSet;
import java.util.TreeSet;

public class _01MostrarHashCode {
	public static void main(String[] args) {
		String nombre1 = "pepe";
		String nombre2 = "luis";
		String nombre3 = "luis";
		
		//El método hashCode de la clase String
		//devuelve un entero a partir de los caracteres
		//que forman el String
		System.out.println(nombre1.hashCode());
		System.out.println(nombre2.hashCode());
		System.out.println(nombre3.hashCode());
		
		System.out.println("----------");
		
		//El método hashCode de la clase Object devuelve
		//un entero calculado a partir de la dirección de 
		//memoria del objeto
		Persona p1 = new Persona("1","Ana");
		Persona p2 = new Persona("2","Pepa");
		Persona p3 = new Persona("2","Pepa");
		System.out.println(p1.hashCode());
		System.out.println(p2.hashCode());
		System.out.println(p3.hashCode());
		
		
		//Consecuencia: Un HashSet de Strings funcionará bien
		//pero uno de Personas funcionará mal
		System.out.println("----------");
		HashSet<String> hs1 = new HashSet<>();
		HashSet<Persona> hs2 = new HashSet<>();
		
		hs1.add(nombre1);
		hs1.add(nombre2);
		hs1.add(nombre3);
		System.out.println(hs1);
		
		hs2.add(p1);
		hs2.add(p2);
		hs2.add(p3);
		System.out.println(hs2);
		
		//Con Alumno funciona bien
		Alumno a1 = new Alumno("1","Ángel");
		Alumno a2 = new Alumno("2","Luis");
		Alumno a3 = new Alumno("2","Luis");
		HashSet<Alumno> hs3 = new HashSet<>();
		hs3.add(a1);
		hs3.add(a2);
		hs3.add(a3);
		System.out.println(hs3);
		
		
		
	}

}
