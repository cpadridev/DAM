package _02ejemplos._08ImportanciaHashCode;

public class Persona {
	private String dni;
	private String nombre;
	
	public Persona(String dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
	}

	public String toString() {
		return dni + " - " + nombre;
	}
}
