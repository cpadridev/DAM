package _02ejemplos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class _05Colecciones {
	public static void main(String[] args) {
		//Todas las colecciones tienen una serie de métodos comunes
		
		Collection<String> vehiculos = new ArrayList<>();
		
		vehiculos.add("casa");
		vehiculos.add("barco");
		vehiculos.add("coche");
		vehiculos.add("moto");
		vehiculos.add("bicicleta");
		System.out.println(vehiculos);
		vehiculos.remove("casa");
		System.out.println(vehiculos);
		
		//La operación de insertar en una posición no está definida 
		//para las Collection
		//vehiculos.add(0,"autobús");
		
		//Operaciones masivas
		ArrayList<String> acuaticos = new ArrayList<>();
		acuaticos.add("barco");
		acuaticos.add("pez");
		
		System.out.println(vehiculos.containsAll(acuaticos));
		
		//Añadir todos los elemento de otra colección
		//vehiculos.addAll(acuaticos);
		//System.out.println(vehiculos);
		
		//Eliminar todos los elementos de otra colección
		//vehiculos.removeAll(acuaticos);
		//System.out.println(vehiculos);
		
		//Dejar solo los elementos de otra coleccion
		//vehiculos.retainAll(acuaticos);
		//System.out.println(vehiculos);
		
		//Eliminar elementos que cumplen una condicion
		//vehiculos.removeIf((e)-> e.length() == 4);
		//System.out.println(vehiculos);
		
		//Devolver array a partir de la coleccion
		
		Object v[] = vehiculos.toArray(); //de colección a array de objetos
		
		//String v2[] = (String[]) vehiculos.toArray();
		
		String w[] = vehiculos.toArray(new String[0]);
		
		//o bien
		String w2[] = new String[vehiculos.size()];
		w2 = vehiculos.toArray(w2);
		
		//De array a List
		String[] nombres = {"pedro","ana","luis"};
		List<String> listaNombres = Arrays.asList(nombres); //No sabemos que implementación
													// de List devuelve
		
		//ArrayList<String> arrayListNombres = Arrays.asList(nombres);
		
		//De array a ArrayList
		ArrayList<String> arrayListNombres = new ArrayList<>(Arrays.asList(nombres));
		
		
		
		
	}
}
