package _02ejemplos;

import java.util.ArrayList;

public class _02ArrayList {
	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<>();
		//Añadiendo al final del arraylist
		long t1 = System.currentTimeMillis();
		
		for(int i = 1; i < 100000; i++) {
			l1.add(i);
		}
		
		long t2 = System.currentTimeMillis();
		System.out.println(t2 - t1);
		
		//Insertando al principio
		ArrayList<Integer> l2 = new ArrayList<>();
		
		t1 = System.currentTimeMillis();
		
		for(int i = 1; i < 100000; i++) {
			l2.add(0,i);
		}
		
		t2 = System.currentTimeMillis();
		System.out.println(t2 - t1);
		
	}

}
