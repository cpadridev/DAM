package _02ejemplos;

import java.util.HashSet;

public class _07RapidezHashSet {
	public static void main(String[] args) {
		final int N = 10000;
		HashSet<Integer> hs1 = new HashSet<>();
		for(int i = 1; i<= N; i++) {
			hs1.add(i);
		}
		
		HashSet<Integer> hs2 = new HashSet<>();
		for(int i = 1; i<= 1000 * N; i++) {
			hs2.add(i);
		}
		
		final int NUMBUSQUEDAS = 100000000;
		long t1 = System.currentTimeMillis();
		for(int i = 0; i< NUMBUSQUEDAS; i++) {
			boolean enc = hs1.contains(0);
		}
		long t2 = System.currentTimeMillis();
		System.out.println(t2-t1);
		
		t1 = System.currentTimeMillis();
		for(int i = 0; i< NUMBUSQUEDAS; i++) {
			boolean enc = hs2.contains(0);
		}
		t2 = System.currentTimeMillis();
		System.out.println(t2-t1);
		
	}

}
