package _02ejemplos._09euromillones;

import java.util.LinkedHashSet;

public class Boleto {
	private LinkedHashSet<Apuesta> apuestas;
	
	public Boleto (int numApuestas) {
		apuestas = new LinkedHashSet<Apuesta>();
		while(apuestas.size() < numApuestas) apuestas.add(new Apuesta());
	}
	public String toString() {
		String result = "";
		for(Apuesta a: apuestas) {
			result += a + "\n";
		}
		return result;
	}

}
