package _02ejemplos._09euromillones;

import java.util.Random;
import java.util.TreeSet;

public class Apuesta {
	final int NUM = 5,EST = 2, MAXNUM = 50, MAXEST = 12;
	static Random r = new Random();
	private TreeSet<Integer> numeros;
	private TreeSet<Integer> estrellas;
	
	public Apuesta() {
		numeros = new TreeSet<>();
		while(numeros.size() < NUM) numeros.add(r.nextInt(MAXNUM) + 1);
		
		estrellas = new TreeSet<>();
		while(estrellas.size() < EST) estrellas.add(r.nextInt(MAXEST) + 1);
		
	}
	
	public String toString() {
		return numeros + " - " + estrellas;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((estrellas == null) ? 0 : estrellas.hashCode());
		result = prime * result + ((numeros == null) ? 0 : numeros.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apuesta other = (Apuesta) obj;
		if (estrellas == null) {
			if (other.estrellas != null)
				return false;
		} else if (!estrellas.equals(other.estrellas))
			return false;
		if (numeros == null) {
			if (other.numeros != null)
				return false;
		} else if (!numeros.equals(other.numeros))
			return false;
		return true;
	}
	
	

}
