package _02ejemplos._09euromillones;

public class Euromillones {
	public static void main(String[] args) {
		Boleto b = new Boleto(4);
		System.out.println(b);
	}

}
