package _02ejemplos._04ListaEnlazada;

public class Test {
	public static void main(String[] args) {
		ListaEnlazada<String> l = new ListaEnlazada<>();
		
		l.add("casa");
		l.add("coche");
		l.add("barco");
		
		System.out.println(l);
	}

}
