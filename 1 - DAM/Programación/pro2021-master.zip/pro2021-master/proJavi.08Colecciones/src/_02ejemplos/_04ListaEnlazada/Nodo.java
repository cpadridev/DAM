package _02ejemplos._04ListaEnlazada;

public class Nodo<T> {
	T dato;
	Nodo<T> siguiente;
}
