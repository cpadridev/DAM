package _02ejemplos._04ListaEnlazada;

public class ListaEnlazada <T> {
	private Nodo<T> primero;
	private Nodo<T> ultimo;
	private int size;
	
	public ListaEnlazada() {
		this.primero = null;
		this.ultimo = null;
		this.size = 0;
	}
	
	public void add(T elemento) {
		//Creamos un nuevo nodo
		Nodo<T> nuevo = new Nodo<>();
		nuevo.dato = elemento;
		nuevo.siguiente = null;
		
		//Lo ponemos a continuación del último
		if(size != 0) {
			ultimo.siguiente = nuevo;
		}
		
		//El nuevo nodo pasa a ser el último de la lista
		ultimo = nuevo;
		
		//El nuevo nodo es el unico? Entonces tambien será el primero
		// de la lista
		if(size == 0 /*primero == null*/ ) {
			primero = nuevo;
		}
		
		//Aumentamos tamaño
		size ++;
	}
	
	public String toString() {
		String result = "";
		Nodo<T> actual = primero;
		while(actual != null) {
			result += actual.dato + " - ";
			actual = actual.siguiente;
		}
		
		return result;
	}
	

}
