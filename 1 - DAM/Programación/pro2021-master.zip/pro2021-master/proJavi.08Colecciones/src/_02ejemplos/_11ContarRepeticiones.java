package _02ejemplos;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


public class _11ContarRepeticiones {
	public static void main(String[] args) {
		String[] palabras = {"A","B","A","C","B","A","C","D","B","E"};
		
		//Averiguar cuántas veces se repite cada String
		//del array (RECORRIENDO EL ARRAY UNA SOLA VEZ)
		
		//Nos apoyaremos en un Map
		Map<String, Integer> m = new LinkedHashMap<>();
		
		for (int i = 0; i < palabras.length; i++) {
			String p = palabras[i];
			
			//Comprobamos cuantas veces ha aparecido antes la palabra
			Integer veces = m.get(p);
			if(veces == null) { //Aun no habia aparecido
				m.put(p, 1);
			} else {
				m.put(p, veces + 1);
			}
		}
		
		System.out.println(m);
		
		//Recorrido de un map
		Set<String> claves = m.keySet();
		for(String clave: claves) {
			Integer veces = m.get(clave);
			System.out.println("La palabra " + clave + " se repite " + veces + " veces");
		}
		
		//También
		System.out.println(" --------- ");
		for(String clave: m.keySet()) {
			System.out.println(clave + " - " + m.get(clave));
		}
		
		//También
		Set<Entry<String,Integer>> parejas = m.entrySet();
		for(Entry<String,Integer> pareja: parejas) {
			System.out.println(pareja.getKey() + " - " + pareja.getValue());
		}
	
		
	}

}
