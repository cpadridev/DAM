import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class _10Matriculas {
	public static void main(String[] args) {
		//El siguiente Map contiene matrículas de vehiculos y su año de matriculacion
		Map<String, Integer> matriculaciones = new HashMap<>();
		matriculaciones.put("1111AAA", 2000);
		matriculaciones.put("1112AAA", 2000);
		matriculaciones.put("1111BBB", 2001);
		matriculaciones.put("1112AAT", 2000);
		matriculaciones.put("1113AAA", 2000);
		matriculaciones.put("1111CCC", 2001);
		matriculaciones.put("1111DDD", 2002);
		matriculaciones.put("1111DfD", 2002);
		
		//Averiguar y mostrar por pantalla cuántos vehiculos se han matriculado cada
		//año
		
		//Map de <año, nº de matriculas de ese año>
		Map<Integer, Integer> matPorAnyo = new TreeMap<>();
		
		//Recorremos las matriculaciones
		for(String matricula: matriculaciones.keySet()) {
			Integer anyo = matriculaciones.get(matricula);
			
			//Comprobamos/contamos numero de matriculas 
			Integer numMatriculaciones = matPorAnyo.get(anyo);
			
			if(numMatriculaciones == null) {
				matPorAnyo.put(anyo, 1);
			} else {
				matPorAnyo.put(anyo, numMatriculaciones + 1);
			}
			
		}
		System.out.println(matPorAnyo);	
	}
}
