package _03ejercicios;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class _01ComparativaRecorridos {
	public static void main(String[] args) {
		final int TAMANYO = 100000;
		List<Integer> l = crearArrayList(TAMANYO);
		long t1 = recorrerFor(l);
		long t2 = recorrerForEach(l);
		long t3 =  recorrerIterator(l);
		l = crearLinkedList(TAMANYO);
		long t4 = recorrerFor(l);
		long t5 = recorrerForEach(l);
		long t6 =  recorrerIterator(l);
		
		l = crearArrayList(2* TAMANYO);
		long t1_2 = recorrerFor(l);
		long t2_2 = recorrerForEach(l);
		long t3_2 =  recorrerIterator(l);
		l = crearLinkedList(2 * TAMANYO);
		long t4_2 = recorrerFor(l);
		long t5_2 = recorrerForEach(l);
		long t6_2 =  recorrerIterator(l);
		
		
		System.out.println("Array List FOR:      " + t1 + " - " + t1_2);
		System.out.println("Array List FOREACH   " + t2 + " - " + t2_2);
		System.out.println("Array List ITERATOR  " + t3 + " - " + t3_2);
		System.out.println("Linked List FOR:  " + t4 + " - " + t4_2);
		System.out.println("Linked List FOREACH:      " + t5 + " - " + t5_2);
		System.out.println("Linked List ITERATOR: " + t6 + " - " + t6_2);
	
		
	}
	
	public static List<Integer> crearArrayList(int numElem){
		ArrayList<Integer> l = new ArrayList<>();
		for (int i = 0; i< numElem; i++){
			l.add(i);
		}
		return l;
	}
	public static List<Integer> crearLinkedList(int numElem){
		LinkedList<Integer> l = new LinkedList<>();
		for (int i = 0; i< numElem; i++){
			l.add(i);
		}
		return l;
	}
	
	public static long recorrerFor(List<Integer>l){
		long antes = System.currentTimeMillis();
		double r = 0;
		for(int i = 0; i < l.size(); i++){
			Integer elemento = l.get(i);
		}
		long despues = System.currentTimeMillis();
		return despues - antes;
	}
	public static long recorrerForEach(List<Integer>l){
		long antes = System.currentTimeMillis();
		
		double r = 0;
		for(Integer i: l){
			Integer elemento = i;
		}
		long despues = System.currentTimeMillis();
		return despues - antes;
	}
	public static long recorrerIterator(List<Integer>l){
		long antes = System.currentTimeMillis();
		
		Iterator<Integer> it = l.iterator();
		double r = 0;
		while(it.hasNext()){
			Integer elemento = it.next();
		}
		long despues = System.currentTimeMillis();
		return despues - antes;
	}
}
