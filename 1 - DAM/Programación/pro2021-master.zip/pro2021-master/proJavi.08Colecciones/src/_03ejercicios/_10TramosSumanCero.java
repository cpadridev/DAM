package _03ejercicios;

import java.util.HashMap;
import java.util.Map;

public class _10TramosSumanCero {
	// Dado un array, mostrar qué tramos del array suman cero

	public static void main(String[] args) {
		int[] v = { 1, 1, 2, -4, 2, 2, 3, -3, -6, 8, 1 };

		Map<Integer, Integer> m = new HashMap<>();

		int suma = 0;
		for (int i = 0; i < v.length; i++) {
			suma = suma + v[i];
			System.out.println(suma);

			if (suma == 0) {
				System.out.println("0 -> " + i + " suma cero");
			} else {
				Integer posicionSuma = m.get(suma);
				if (posicionSuma == null) {
					// La suma no había aparecido hasta ahora
					m.put(suma, i);
				} else {
					// La suma ya habia aparecido => El tramo desde
					// que apareció hasta la posicion actual suma cero
					System.out.println(posicionSuma + 1 + " -> " + i + " suma cero");
				}
			}
		}

	}

}
