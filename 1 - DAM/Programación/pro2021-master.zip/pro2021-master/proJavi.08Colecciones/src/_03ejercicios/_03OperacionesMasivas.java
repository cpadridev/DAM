package _03ejercicios;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class _03OperacionesMasivas {
	public static void main(String[] args) {
		Integer[] a = { 1, 3, 5, 7, 9, 1, 3 };

		Integer[] b = { 2, 4, 6, 8, 10 };

		System.out.println(Arrays.toString(quitarDuplicados(a)));
		System.out.println(Arrays.toString(diferencia(a,b)));
		

	}

	public static Integer[] quitarDuplicados(Integer[] v) {
		// Creamos un Set a partir de los elementos de v
		Set<Integer> s = new LinkedHashSet<>(Arrays.asList(v));

		// Volcar el set a un array y devolverlo
		Integer[] res = s.toArray(new Integer[0]);
		return res;
	}

	// Con arrays de int sería un poco mas elaborado ...
	public static int[] quitarDuplicados2(int[] v) {
		// Creamos un Set a partir de los elementos de v
		Set<Integer> s = new LinkedHashSet<Integer>();
		for (int i : v) {
			s.add(i);
		}

		// Volcar el set a un array y devolverlo
		int[] res = new int[s.size()];
		int i = 0;
		for (Integer num : s) {
			v[i++] = num;
		}
		return res;
	}

	public static Integer[] union(Integer[] v1, Integer v2[]) {
		// Pasamos los elementos a un set
		Set<Integer> s = new LinkedHashSet<>(Arrays.asList(v1));
		s.addAll(Arrays.asList(v2));

		// Volcar el set a un array y devolverlo
		Integer[] res = s.toArray(new Integer[0]);
		return res;

	}

	public static Integer[] interseccion(Integer[] v1, Integer v2[]) {
		Set<Integer> s1 = new LinkedHashSet<>(Arrays.asList(v1));
		Set<Integer> s2 = new LinkedHashSet<>(Arrays.asList(v2));

		s1.retainAll(s2);
		// Volcar el set a un array y devolverlo
		Integer[] res = s1.toArray(new Integer[0]);
		return res;
	}

	public static Integer[] diferencia (Integer[] v1, Integer v2[]) {
		List<Integer> s1 = new LinkedList<>(Arrays.asList(v1));
		List<Integer> s2 = new LinkedList<>(Arrays.asList(v2));

		s1.removeAll(s2);
		
		// Volcar el set a un array y devolverlo
		Integer[] res = s1.toArray(new Integer[0]);
		return res;
	}
	
	
}
