package _03ejercicios;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class _08Diccionario {
	public static void main(String[] args) {
		Map<String, Set<String>> diccionario = new TreeMap<>();
		anyadirTraduccion(diccionario,"casa","house");
		anyadirTraduccion(diccionario,"casa","home");
		anyadirTraduccion(diccionario,"estropeado","broken");
		anyadirTraduccion(diccionario,"estropeado","out of order");
		
		System.out.println(diccionario);
		
		quitarTraduccion(diccionario,"casa","home");
		System.out.println(diccionario);
		
		quitarTraduccion(diccionario,"casa","house");
		System.out.println(diccionario);
	}

	public static boolean anyadirTraduccion(Map<String, Set<String>> diccionario, String cast, String ingl) {
		Set<String> traducciones = diccionario.get(cast);
		if(traducciones == null) {
			//La palabra en castellano no estaba en el diccionario. Hay que añadir
			//la pareja al map. Tenemos que crear un Set y añadir la traducción
			traducciones = new TreeSet<>();
			traducciones.add(ingl);
			diccionario.put(cast, traducciones);
			return true;
		} else {
			//La palabra en castellano ya tenía alguna traducción. Añadimos la nueva
			return traducciones.add(ingl);
		}
	}
	
	public static boolean quitarTraduccion(Map<String, Set<String>> diccionario, String cast, String ingl) {
		//Obtenemos las traducciones de la palabra en castellano
		Set<String> traducciones = diccionario.get(cast);
		if(traducciones == null) {
			//La pareja no está en el diccionario. No se puede borrar
			return false;
		} else {
			//La palabra en castellano está. Eliminamos (si está) su traducción
			boolean eliminada = traducciones.remove(ingl);
			if(eliminada && traducciones.size() == 0) {
				//Si la palabra se queda sin traducciones, la eliminamos del diccionario
				diccionario.remove(cast);
			}
			return eliminada;
		}
		
	}
	
	public static Collection<String> traduccionesDe(Map<String, Set<String>> diccionario, String cast) {
		return diccionario.get(cast);
	}

}
