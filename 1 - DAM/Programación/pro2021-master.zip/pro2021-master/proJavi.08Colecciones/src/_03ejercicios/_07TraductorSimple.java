package _03ejercicios;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class _07TraductorSimple {
	public static void main(String[] args) {
		
		//leer el fichero y pasarlo a un Map
		Map<String,String> m = new HashMap<>();
		Scanner f = null;
		try {
			f = new Scanner(new File("palabras.txt"));
			while(f.hasNext()) {
				String castellano = f.next().trim();
				String ingles = f.nextLine().trim();
				m.put(castellano,ingles);			
			}
			
		} catch (FileNotFoundException e) {
			System.out.println("El fichero no existe o no se puede abrir");
		} finally {
			if (f != null) {
				f.close();
			}
		}
		System.out.println(m);
		
		//El usuario introduce una frase y la traducimos
		Scanner tec = new Scanner(System.in);
		System.out.println("Frase: ");
		String frase = tec.nextLine();
		
		//Descomponemos la frase en palabras 
		String[] palabras = frase.split(" ");
		String traducida = "";
		
		for (int i = 0; i < palabras.length; i++) {
			String traduccion = m.get(palabras[i]);
			if(traduccion == null) traducida += " " + palabras[i];
			else traducida += " " + traduccion;
			
		}
		System.out.println(traducida);
		
	}
	
	
}






