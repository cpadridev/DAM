package _03ejercicios;

import java.util.Arrays;
import java.util.List;

public class _09FaltasBaloncesto {
	public static void main(String[] args) {
		List<String> faltas = Arrays.asList(
				new String[] {"J1","J2","J3","J1","J2","J3","J1","J1","J3","J4","J1","J2","J3","J2"}
				);
	}

}
