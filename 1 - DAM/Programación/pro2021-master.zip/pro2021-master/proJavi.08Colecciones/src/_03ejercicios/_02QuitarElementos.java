package _03ejercicios;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

public class _02QuitarElementos {
	public static void main(String[] args) {
		ArrayList<String> l = new ArrayList<>(Arrays.asList(
				new String[] {"antepuesto","postgrado","casa", "postponer"}));
		quitarElementosPrefijo(l, "post");
		System.out.println(l);
		

	}
	public static void quitarElementosPrefijo (Collection<String> c, String prefijo) {{
		Iterator <String> it = c.iterator();
		while(it.hasNext()) {
			String s = it.next();
			//if(s.startsWith(prefijo)) {
			if(s.indexOf(prefijo) == 0) {
				it.remove();
			}
		}
		
	}
		
	}
}
