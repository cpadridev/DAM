package _03ejercicios;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class _04Futbol {
	public static void main(String[] args) {
		String[] equipos = { "A", "B", "C", "D", "E" };
		String[][] partidos = { { "A", "B" }, { "A", "C" }, { "A", "D" }, { "B", "C" } };
		System.out.println(Arrays.toString(hanJugadoCasa(equipos, partidos)));

	}

	public static String[] hanJugadoCasa(String[] nombres, String[][] partidos) {
		// Si pasamos el primer equipo de cada partido a un set,
		// tendremos todos los que han jugado en casa, sin duplicados
		Set<String> s = new TreeSet<String>();
		for (int i = 0; i < partidos.length; i++) {
			s.add(partidos[i][0]);
		}
		// Pasamos el set a un array
		String[] resultado = s.toArray(new String[0]);
		return resultado;
	}

	public static String[] hanJugadoFuera(String[] nombres, String[][] partidos) {
		// Si pasamos el segundo equipo de cada partido a un set,
		// tendremos todos los que han jugado fuera de casa, sin duplicados
		Set<String> s = new TreeSet<String>();
		for (int i = 0; i < partidos.length; i++) {
			s.add(partidos[i][1]);
		}
		// Pasamos el set a un array
		String[] resultado = s.toArray(new String[0]);
		return resultado;
	}

	public static String[] noHanJugadoCasa(String[] nombres, String[][] partidos) {
		// Paso los equipos existentes a un Set
		Set<String> s = new TreeSet<>(Arrays.asList(nombres));
		// Elimino los que han jugado en casa
		for (int i = 0; i < partidos.length; i++) {
			s.remove(partidos[i][0]);
		}
		// Pasamos el set a un array
		String[] resultado = s.toArray(new String[0]);
		return resultado;
	}

	public static String[] noHanJugadoCasa3(String[] nombres, String[][] partidos) {
		// Equipos que han jugdo en casa
		Set<String> si = new TreeSet<String>();
		for (int i = 0; i < partidos.length; i++) {
			si.add(partidos[i][0]);
		}
		
		// Paso los equipos existentes a un Set
		Set<String> no = new TreeSet<>(Arrays.asList(nombres));
		no.removeAll(si);
		
		// Pasamos el set a un array
		String[] result = no.toArray(new String[0]);
		return result;
	}

}
