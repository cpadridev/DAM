package _02ejemplos._02cuentas;

public class TestCuenta {
	public static void main(String[] args) {
		Cuenta c = new Cuenta("javi", "ABC1234");
		System.out.println(c);
	}
}
