package _01pruebas;

import java.util.ArrayList;

public class Prueba {
	public static void main(String[] args) {
		ArrayList<String> l = new ArrayList<>();
		
		l.add("a");
		l.add("a");
		l.add("a");
		l.add(3,"b");
		System.out.println(l);
	}

}
